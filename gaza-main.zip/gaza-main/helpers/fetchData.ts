export async function fetchData({
  url,
  page,
  locale,
}: {
  url: string;
  page?: string;
  locale: string;
}) {
  const pageQuery = page ? `?page=${page || 1}` : "";
  const baseUrl = "https://gdd-api.secdy.com/api";
  const apiurl = baseUrl + url + "/" + pageQuery;

  const res = await fetch(apiurl, {
    headers: {
      "Accept-Language": locale.toLocaleLowerCase(),
    },
  });
  return res.json();
}
