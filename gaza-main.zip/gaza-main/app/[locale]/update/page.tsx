import UpdateData from "@/app/components/Update";
import React from "react";
import { cookies } from "next/headers";
import { redirect } from "@/navigation";

function UpdateDataPage() {
  const cookieStore = cookies();
  const token = cookieStore.get("token")?.value;
  const role = cookieStore.get("role")?.value;

  if (!token || role !== "admin") {
    redirect("/");
  }

  return <UpdateData />;
}

export default UpdateDataPage;
