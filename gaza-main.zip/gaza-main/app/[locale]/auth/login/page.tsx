"use client";

import AuthCard from "@/app/components/auth/AuthCard";
import MobileFooter from "@/app/components/auth/MobileFooter";
import { useRouter } from "@/navigation";
import { useTranslations } from "next-intl";
import { useSearchParams } from "next/navigation";
import React from "react";

function LoginPage() {
  const t = useTranslations();
  const { push } = useRouter();
  const searchParams = useSearchParams();

  const callback = searchParams.get("callback");

  const content = {
    pageName: "login",
    title: t("Login"),
    form: {
      email: {
        text: t("Email Address"),
      },
      password: {
        text: t("Password"),
      },
      btn: {
        text: t("Login"),
      },
    },
    sideContent: {
      title: t("Do not have an account"),
      subtitle: t(
        "Register Your Organization Now for Full Access to Daily Updates",
      ),
      btn: {
        text: t("Sign Up Now!"),
        action: () => {
          push(`/auth/register${callback ? `?callback=${callback}` : ""}`);
        },
      },
    },
  };
  return (
    <>
      <div className="mb-[93px] flex justify-center px-4  md:mb-[200px]">
        <AuthCard content={content} />
      </div>
      <MobileFooter sideContent={content.sideContent} />
    </>
  );
}

export default LoginPage;
