"use client";

import AuthCard from "@/app/components/auth/AuthCard";
import MobileFooter from "@/app/components/auth/MobileFooter";
import { useRouter } from "@/navigation";
import { useTranslations } from "next-intl";
import React from "react";
import { useSearchParams } from "next/navigation";

function RegisterPage() {
  const t = useTranslations();
  const { push } = useRouter();
  const searchParams = useSearchParams();

  const callback = searchParams.get("callback");
  
  const content = {
    pageName: "register",
    title: t("Create a New Account"),
    form: {
      email: {
        text: t("Email Address"),
      },
      username: {
        text: t("Username"),
      },
      password: {
        text: t("Password"),
      },
      confirmPassword: {
        text: t("Confirm Password"),
      },
      btn: {
        text: t("Register"),
      },
    },
    sideContent: {
      title: t("Have an account"),
      btn: {
        text: t("Login"),
        action: () => {
          push(`/auth/login${callback ? `?callback=${callback}` : ""}`);
        },
      },
    },
  };
  return (
    <>
      <div className="mb-[93px] flex justify-center px-4  md:mb-[200px]">
        <AuthCard content={content} />
      </div>
      <MobileFooter sideContent={content.sideContent} />
    </>
  );
}

export default RegisterPage;
