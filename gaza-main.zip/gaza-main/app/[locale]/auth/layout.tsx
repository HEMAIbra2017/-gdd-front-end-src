import React from "react";

function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className=" mt-[50px]   md:mt-[101px]">
      {children}
    </div>
  );
}

export default AuthLayout;
