import React from "react";
import { ConfigProvider } from "antd";

import StyledComponentsRegistry from "../../lib/AntdRegistry";
import { primary } from "@/app/fonts/font";

import "../globals.css";
import "../styles.scss";
import { NextIntlClientProvider, useMessages } from "next-intl";
import MainHeader from "../components/ui/MainHeader";
import { getTranslations } from "next-intl/server";
import Update from "../components/ui/Update";
import Script from "next/script";
import Head from "next/head";

export async function generateMetadata({
  params: { locale },
}: {
  params: { locale: string };
}) {
  const t = await getTranslations({ locale, namespace: "metadata" });

  return {
    title: t("title"),
    description: t("description"),
  };
}

function RootLayout({
  children,
  params: { locale },
}: {
  children: React.ReactNode;
  params: { locale: string };
}) {
  const messages = useMessages();
  return (
    <html
      dir={locale == "ar" ? "rtl" : "ltr"}
      className={`${primary.variable} `}
      lang={locale}
    >
      <body className="relative" suppressHydrationWarning={true}>
        <StyledComponentsRegistry>
          <ConfigProvider
            theme={{
              token: {
                fontFamily: "var(--font-primary)",
              },
            }}
            direction={locale == "ar" ? "rtl" : "ltr"}
          >
            <NextIntlClientProvider locale={locale} messages={messages}>
              <div className="flex min-h-screen flex-col">
                <MainHeader />
                {children}
                <Update />
              </div>
            </NextIntlClientProvider>
          </ConfigProvider>
        </StyledComponentsRegistry>
      </body>
      <Script
        id="clarity_id"
        dangerouslySetInnerHTML={{
          __html: `
            (function(c,l,a,r,i,t,y){
              c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
              t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
              y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
          })(window, document, "clarity", "script", "luy2k77w32")
      `,
        }}
      ></Script>
      <Script
        async
        data-id="7825355899"
        id="chatling-embed-script"
        type="text/javascript"
        src="https://chatling.ai/js/embed.js"
      ></Script>
    </html>
  );
}

export default RootLayout;
