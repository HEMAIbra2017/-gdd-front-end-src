import React from "react";
import CostsTable from "@/app/components/tables/costs";
import { fetchData } from "@/helpers/fetchData";
import { useLocale } from "next-intl";
async function CostsPage() {
  const locale = useLocale();

  const data = await fetchData({
    url: "/summary",
    locale,
  });

  return <CostsTable data={data} />;
}

export default CostsPage;
