import React from "react";
import Gaza from "@/app/components/Gaza";

async function GazaPage() {
  return <Gaza />;
}

export default GazaPage;
