import React from "react";
import ActionsTable from "@/app/components/tables/actions";
import { fetchData } from "@/helpers/fetchData";
import { useLocale } from "next-intl";
async function ActionsPage({
  searchParams,
}: {
  searchParams: {
    social?: string;
    infrastructure?: string;
    economic: string;
    governance: string;
  };
}) {
  const locale = useLocale();

  const socialData = await fetchData({
    url: `/actions/sector/3`,
    page: searchParams?.social,
    locale,
  });
  const infrastructureData = await fetchData({
    url: `/actions/sector/1`,
    page: searchParams?.infrastructure,
    locale,
  });
  const economicData = await fetchData({
    url: `/actions/sector/2`,
    page: searchParams?.economic,
    locale,
  });
  const governanceData = await fetchData({
    url: `/actions/sector/4`,
    page: searchParams?.governance,
    locale,
  });
  const data = [
    {
      name: "social",
      title: {
        className: "bg-[#4DA046] ",
      },
      sectionData: socialData,
    },
    {
      name: "infrastructure",
      title: {
        className: "bg-[#F99E2B]",
      },
      sectionData: infrastructureData,
    },
    {
      name: "economic",
      title: {
        className: "bg-[#A31D44]",
      },
      sectionData: economicData,
    },
    {
      name: "governance",
      title: {
        className: "bg-[#16486D] ",
      },
      sectionData: governanceData,
    },
  ];

  return <ActionsTable data={data} />;
}

export default ActionsPage;
