import ActionButton from "@/app/components/ui/ActionButton";
import Footer from "@/app/components/ui/footer/Footer";
import React from "react";

const DashboardLayout = ({ children }: React.PropsWithChildren) => (
  <div className="flex flex-col">
    <div className="">
      {children}
      <ActionButton />
    </div>
    <Footer />
  </div>
);

export default DashboardLayout;
