import React from "react";
import AchievementsTable from "@/app/components/tables/achievements";
import { fetchData } from "@/helpers/fetchData";
import { useLocale } from "next-intl";
async function AchievementsPage({
  searchParams,
}: {
  searchParams: {
    social?: string;
    infrastructure?: string;
    economic: string;
    governance: string;
  };
}) {
  const locale = useLocale();

  const socialData = await fetchData({
    url: `/actions/sector/3`,
    page: searchParams?.social,
    locale,
  });
  const infrastructureData = await fetchData({
    url: `/actions/sector/1`,
    page: searchParams?.infrastructure,
    locale,
  });
  const economicData = await fetchData({
    url: `/actions/sector/2`,
    page: searchParams?.economic,
    locale,
  });
  const governanceData = await fetchData({
    url: `/actions/sector/4`,
    page: searchParams?.governance,
    locale,
  });
  const data = [
    {
      name: "social",
      title: {
        className: "bg-[#4DA046] ",
      },
      sectionData: socialData,
    },
    {
      name: "infrastructure",
      title: {
        className: "bg-[#F99E2B]",
      },
      sectionData: infrastructureData,
    },
    {
      name: "economic",
      title: {
        className: "bg-[#A31D44]",
      },
      sectionData: economicData,
    },
    {
      name: "governance",
      title: {
        className: "bg-[#16486D] ",
      },
      sectionData: governanceData,
    },
  ];

  return <AchievementsTable data={data} />;
}

export default AchievementsPage;
