import React from "react";
import DamagesTable from "@/app/components/tables/damages";
import { fetchData } from "@/helpers/fetchData";
import { useLocale } from "next-intl";
async function DamagesPage({
  searchParams,
}: {
  searchParams: { page?: string; };
}) {
  const locale = useLocale();

  const data = await fetchData({
    url: "/damage-reports",
    page: searchParams?.page,
    locale,

  });
  return <DamagesTable data={data} />;
}

export default DamagesPage;
