import React from "react";
import MainDashboard from "@/app/components/MainDashboard";

function Home() {
  return <MainDashboard />;
}

export default Home;
