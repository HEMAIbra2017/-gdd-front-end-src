import React from "react";

function NotFound() {
  return (
    <div dir="ltr" className="flex flex-col gap-y-4 justify-center items-center mt-20">
      <h1 className="text-black3 text-4xl font-semibold">Oops! That page can’t be found.</h1>
      <p className="text-gray2 font-light">It looks like nothing was found at this location</p>
    </div>
  );
}

export default NotFound;
