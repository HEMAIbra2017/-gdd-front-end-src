"use client"; // Error components must be Client Components

import { Alert, Button } from "antd";
import { useEffect } from "react";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <Alert
      message={error?.name || "Error happened"}
      description={error?.message}
      type="error"
      action={
        <button
          className="rounded-lg bg-primary px-4 py-2 text-white"
          onClick={() => reset()}
        >
          حاول مرة أخرى
        </button>
      }
    />
  );
}
