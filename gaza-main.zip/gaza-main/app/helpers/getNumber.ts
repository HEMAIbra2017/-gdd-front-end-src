export default function  getNumber(num:string){
    return  parseFloat(num?.replace(/,/g, ''));
}