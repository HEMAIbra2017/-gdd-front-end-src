export default function formatNumber(item: number) {
  if (typeof item == "number") {
    return item.toLocaleString();
  } else if (!isNaN(item)) {
    return (+item).toLocaleString();
  } else {
    return item;
  }
}
