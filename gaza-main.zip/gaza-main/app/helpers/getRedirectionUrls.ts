export default function getRedirectionUrls({ locale }: { locale: string }) {
  const baseUrl = "https://gdd.org";
  const donate: any = {
    en: "/give/",
    ar: "/ar/donate/",
    tr: "/tr/bagis-2/",
    ID: "/give/",
  };

  const contact: any = {
    en: "/contact/",
    ar: "/ar/التواصل-معنا/",
    tr: "/tr/iletisim/",
    ID: "/contact/",
  };
  const campaigns: any = {
    en: "/campaigns/",
    ar: "/ar/الحملات/",
    tr: "/tr/kampanyalar/",
    ID: "/campaigns/",
  };
  const news: any = {
    en: "/news/",
    ar: "/ar/أخبار/",
    tr: "/tr/haberler/",
    ID: "/news/",
  };
  const partners: any = {
    en: "/partners/",
    ar: "/ar/الشركاء/",
    tr: "/tr/ortaklar/",
    ID: "/partners/",
  };

  return {
    donateUrl: baseUrl + donate[locale],
    contactUrl: baseUrl + contact[locale],
    campaignsUrl: baseUrl + campaigns[locale],
    newsUrl: baseUrl + news[locale],
    partnersUrl: baseUrl + partners[locale],
  };
}
