"use client";
import { Card, Table } from "antd";
import React from "react";

function ViewCard({ cardData }: { cardData: any }) {
  return (
    <>
      {cardData?.map((damage: any) => {
        const getDataSource = (data: any) => {
          return data?.map(
            ({
              name,
              factor,
              approvedNumber,
              amoutPerUnitCost,
              totalAmount,
            }: any) => ({
              key: name,
              name,
              factor,
              approvedNumber,
              amoutPerUnitCost,
              totalAmount,
            })
          );
        };

        const columns = [
          {
            title: "نوع التدخل",
            dataIndex: "name",
            key: "name",
          },
          {
            title: "معامل التقدير ",
            dataIndex: "factor",
            key: "factor",
          },
          {
            title: "العدد المعتمد ",
            dataIndex: "approvedNumber",
            key: "approvedNumber",
          },
          {
            title: "قيمة التدخل/تكلفة وحدة التدخل$",
            dataIndex: "amoutPerUnitCost",
            key: "amoutPerUnitCost",
          },
          {
            title: "إجمالي التكلفة العامة$",
            dataIndex: "totalAmount",
            key: "totalAmount",
          },
        ];

        return (
          <div  className="break-inside-avoid" key={damage.id}>
            <Card  headStyle={{backgroundColor:"#009971", color: "white"}} title={`${damage?.name} ( ${damage?.number} )`}>
              <Table
                scroll={{ x: 400, y: 400 }}
                pagination={false}
                dataSource={getDataSource(damage?.helpTypes)}
                columns={columns}
              />
              {damage?.details
                ? damage.details?.map((detail: any) => (
                    <Card
                    headStyle={{backgroundColor:"#caae7c", color: "white"}}
                      style={{ marginTop: 16 }}
                      type="inner"
                      key={detail.id}
                      title={`${detail?.name} ( ${detail?.number} )`}
                    >
                      <Table
                        scroll={{ x: 400, y: 400 }}
                        pagination={false}
                        dataSource={getDataSource(detail?.helpTypes)}
                        columns={columns}
                      />
                    </Card>
                  ))
                : null}
            </Card>
          </div>
        );
      })}
    </>
  );
}

export default ViewCard;
