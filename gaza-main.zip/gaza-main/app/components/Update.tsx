"use client";

import React, { useState } from "react";
import { CloudUploadOutlined } from "@ant-design/icons";
import type { UploadProps } from "antd";
import { Button, message, Upload } from "antd";
import axios from "axios";
import { useRouter } from "@/navigation";
import { clearCache } from "../actions";
const { Dragger } = Upload;

const UpdateData = () => {
  const [loading, setLoading] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const { push } = useRouter();
  const props: UploadProps = {
    accept: ".xlsx",
    name: "file",
    multiple: false,
    action: "/apis/upload",
    onChange(info) {
      const { status, response } = info.file;
      if (status === "done") {
        setShowConfirm(true);
        const messageText = response?.message || "file uploaded successfully.";
        message.success(messageText);
      } else if (status === "error") {
        const messageText =
          response?.detail || `${info.file.name} file upload failed.`;
        message.error(messageText);
      }
    },
  };

  const confirmUpdate = () => {
    setLoading(true);
    axios
      .post("/apis/confirm-update")
      .then((res: any) => {
        if (res?.status == 200 && res?.data?.message) {
          message.success(res?.data?.message);
          clearCache().then(() => {
            push("/");
          });
        } else {
          message.error("An Error occurred");
        }
      })
      .catch((err: any) => {
        message.error(err.message || "An Error occurred");
      })
      .finally(() => {
        setLoading(false);
      });
  };
  return (
    <div className="mx-auto mt-[152px] flex max-w-xs flex-col gap-y-5 rounded-3xl border-[0.5px] border-primary bg-[#E6F5F1]  p-6 sm:max-w-2xl">
      <Dragger {...props}>
        <p className="ant-upload-drag-icon">
          <CloudUploadOutlined />
        </p>
        <p className="ant-upload-text">
          Click or drag file to this area to upload
        </p>
        <p className="ant-upload-hint">Support for a single .xlsx file only</p>
      </Dragger>
      {showConfirm ? (
        <Button
          loading={loading}
          className="w-fit !bg-primary !text-white"
          onClick={() => confirmUpdate()}
        >
          Confirm
        </Button>
      ) : null}
    </div>
  );
};

export default UpdateData;
