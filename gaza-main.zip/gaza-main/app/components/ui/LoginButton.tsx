import React, { useState } from "react";
import loginIcon from "@/public/icons/login.svg";
import Image from "next/image";
import { deleteCookie, getCookie } from "cookies-next";
import { usePathname, useRouter } from "@/navigation";
import { Button, message } from "antd";
import axios from "axios";
function LoginButton({ t }: any) {
  const [loading, setLoading] = useState(false);
  const { push, refresh } = useRouter();
  const pathname = usePathname();
  const token = getCookie("token");
  const handleClick = async () => {
    if (token) {
      setLoading(true);
      const res = axios
        .post("/apis/logout")
        .then((res) => {
          
          if (res.status == 200) {
            deleteCookie("token");
            deleteCookie("role");

            const messageText = res?.data?.message;
            if (messageText) {
              message.success(messageText);
            }
            refresh();
          }
        })
        .catch((error) => {
          
          const status = error?.response?.status;
          if (status == 500) {
            const messageText = error?.response?.statusText;
            message.error(messageText);
          }
        })
        .finally(() => {
          setLoading(false);
        });
    } else {
      push(`/auth/login?callback=${pathname}`);
    }
  };
  return (
    <Button
      loading={loading}
      dir="rtl"
      size="large"
      icon={
        <div className="h-auto w-[18px]">
          <Image
            src={loginIcon}
            alt="login-icon"
            className={` h-auto w-auto ${token ? "rotate-180" : ""} `}
          />
        </div>
      }
      onClick={handleClick}
      className="!focus-within:border-primary !focus-within:text-primary !flex !h-[50px] w-fit   !items-center gap-x-2 rounded-2xl !border !border-primary !px-4 !text-center !text-sm !font-semibold !text-primary "
    >
      {token ? t("Logout") : t("Login")}
    </Button>
  );
}

export default LoginButton;
