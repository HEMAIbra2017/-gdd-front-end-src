"use client";
import React, { useEffect, useState } from "react";
import Image from "next/image";
import {
  FacebookShareButton,
  TelegramShareButton,
  TwitterShareButton,
  WhatsappShareButton,
} from "react-share";

import { usePathname } from "next/navigation";
import { useTranslations } from "next-intl";

function ActionButton() {
  const t = useTranslations()
  const [origin, setOrigin] = useState("");
  const pathname = usePathname();
  
  useEffect(() => {
    if (typeof window !== "undefined") {
      setOrigin(window.location.origin);
    }
  }, []);

  const url = `${origin}${pathname}`;

  return (
    <div className="center flex gap-x-[25px] px-4 py-[26px] sm:py-[43px]">
      <span className="sm:text-xl">{t("Share Data With:")}</span>
      <div className="flex items-center gap-x-4">
        <FacebookShareButton url={url}>
          <Image
            src="/icons/fb-share.svg"
            width={24}
            height={24}
            alt="facebook share icon"
          />
        </FacebookShareButton>
        <WhatsappShareButton url={url}>
          <Image
            src="/icons/whatsapp-share.svg"
            width={24}
            height={24}
            alt="facebook share icon"
          />
        </WhatsappShareButton>
        <TelegramShareButton url={url}>
          <Image
            src="/icons/telegram-share.svg"
            width={24}
            height={24}
            alt="facebook share icon"
          />
        </TelegramShareButton>
        <TwitterShareButton url={url}>
          <Image
            src="/icons/twitter-share.svg"
            width={24}
            height={24}
            alt="facebook share icon"
          />
        </TwitterShareButton>
      </div>
    </div>
  );
}

export default ActionButton;
