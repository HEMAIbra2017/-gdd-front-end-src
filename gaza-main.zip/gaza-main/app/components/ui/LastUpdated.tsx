import Image from "next/image";
import React from "react";

function LastUpdated({
  last_updated: { time, date },
}: {
  last_updated: { time: string; date: string };
}) {
  return (
    <div className="flex w-max items-center gap-x-1  rounded-[6px] border border-darkGreen  bg-lightGreen p-2 text-[10px] text-darkGreen sm:text-xs  ">
      <Image src="/icons/clock.svg" alt="clock icon" width={20} height={20} />
      <span>{date} - </span>
      <span>{time}</span>
    </div>
  );
}

export default LastUpdated;
