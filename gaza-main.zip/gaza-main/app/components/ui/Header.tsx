"use client";
import React from "react";
import { Logo } from "../icons";
import Image from "next/image";
import DonateButton from "./DonateButton";
import Navigation from "./Navigation";
import Burger from "./Burger";
import LangButton from "./LangButton";
import { useRouter } from "@/navigation";
import HeaderLastUpdated from "./HeaderLastUpdated";
import LoginButton from "./LoginButton";
import { useLocale, useTranslations } from "next-intl";

function Header({
  last_updated,
  days_of_genocide,
}: {
  last_updated: { date: string; time: string };
  days_of_genocide: string;
}) {
  const { push } = useRouter();
  const t = useTranslations();
  const locale = useLocale();
  return (
    <div
      className={` sticky top-0 z-50 flex items-center justify-between gap-x-3  overflow-auto border-b-[0.5px] border-b-[#8F8F8F] bg-white px-3 py-4  scrollbar-hide xl:py-6 ${locale == "ar" ? "flex-row-reverse xl:flex-row" : ""}`}
    >
      <div
        className={`  flex items-center gap-x-3 ${locale == "ar" ? "flex-row-reverse xl:flex-row" : ""}`}
      >
        <Image
          onClick={() => {
            push("/");
          }}
          alt="app-logo"
          className=" h-[32px] w-[99px] cursor-pointer xl:h-auto xl:w-auto"
          src={Logo}
        />
        <div
          className={`flex items-center gap-x-5 xl:hidden ${locale == "ar" ? "flex-row-reverse xl:flex-row" : ""}`}
        >
          <HeaderLastUpdated t={t} last_updated={last_updated} />
          <LangButton />
        </div>
      </div>

      <Burger t={t} />
      <div className="hidden xl:inline-flex">
        <Navigation t={t} />
      </div>

      <div className="hidden items-center gap-x-3 xl:flex 2xl:gap-x-2">
        <LangButton />
        <HeaderLastUpdated t={t} last_updated={last_updated} />
        <LoginButton t={t} />
        <DonateButton t={t} />
      </div>
      {days_of_genocide ? (
        <div
          className={`absolute bottom-0  font-light sm:font-normal right-0 bg-red3 px-[6px] py-1 text-xs text-white sm:text-sm`}
        >
          {`${t("Days of Genocide")} ${parseInt(days_of_genocide)}`}
        </div>
      ) : null}
    </div>
  );
}

export default Header;
