

import React, { ReactNode } from "react";
import LastUpdated from "./LastUpdated";

function TablePageLayout({
  text,
  children,
  className,
}: {
  text: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={`container ${className ?? ""}`}>
      <div className="mb-5 flex flex-col gap-x-10 gap-y-4 md:flex-row  md:items-center md:gap-y-0">
        <h1 className=" text-2xl  lg:text-[32px]   ">{text}</h1>
        {/* <LastUpdated /> */}
      </div>
      {children}
    </div>
  );
}

export default TablePageLayout;
