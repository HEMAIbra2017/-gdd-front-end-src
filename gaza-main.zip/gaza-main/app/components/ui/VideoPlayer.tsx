import React from "react";

function VideoPlayer({ videoUrl }: { videoUrl: string }) {
  return (
    <div
      style={{
        position: "relative",
        paddingBottom: "56.25%",
        height: 0,
        overflow: "hidden",
        borderRadius: "32px",
      }}
    >
      {" "}
      <iframe
        style={{
          width: "100%",
          height: "100%",
          position: "absolute",
          left: "0px",
          top: "0px",
          overflow: "hidden",
        }}
        src={videoUrl}
        width="100%"
        height="100%"
        title="Dailymotion Video Player"
        allow="autoplay"
      >
        {" "}
      </iframe>{" "}
    </div>
  );
}

export default VideoPlayer;
