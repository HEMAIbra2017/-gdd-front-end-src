import React from "react";
import Header from "./Header";
import News from "../MainDashboard/ui/News";
import { fetchData } from "@/helpers/fetchData";
import { useLocale } from "next-intl";

async function MainHeader() {
  const locale = useLocale();

  const data = await fetchData({
    url: "/main",
    locale,
  });

  return (
    <>
      <Header days_of_genocide={data?.news?.[0]?.days_of_genocide} last_updated={data?.last_updated} />
      <News news={data?.news?.[0]?.news} />
    </>
  );
}

export default MainHeader;
