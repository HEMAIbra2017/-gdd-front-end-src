import React from "react";
import Image from "next/image";
import { FacebookIcon, InstaIcon, TwitterIcon, YoutubeIcon } from "./icons";
import { useLocale } from "next-intl";
import getRedirectionUrls from "@/app/helpers/getRedirectionUrls";

function FooterBottom({ t }: any) {
  const locale = useLocale();
  const { contactUrl, campaignsUrl, newsUrl, partnersUrl } = getRedirectionUrls(
    { locale },
  );

  return (
    <div className="flex flex-col justify-between gap-y-[26px] text-white md:flex-row md:items-center md:gap-y-0 ">
      <p className="hidden text-xs font-light md:inline-flex">
        {t("footerCopyright")}
      </p>
      <div className="flex items-center justify-between gap-x-8 text-xs md:text-base  ">
        <a target="_blank" href={contactUrl} className="cursor-pointer">
          {t("Contact")}
        </a>
        <a target="_blank" href={campaignsUrl} className="cursor-pointer">
          {t("Campaigns")}
        </a>
        <a target="_blank" href={newsUrl} className="cursor-pointer">
          {t("News")}
        </a>
        <a target="_blank" href={partnersUrl} className="cursor-pointer">
          {t("Our Partners")}
        </a>
      </div>
      <div className="flex items-center justify-between ">
        <p className="text-xs font-light md:hidden">{t("footerCopyright")}</p>

        <div className="flex items-center gap-x-6">
          <a
            target="_blank"
            href="https://www.youtube.com/channel/UCAer3KlJNH3Aedm7eSbWWkg"
          >
            <Image
              className="h-auto w-4 cursor-pointer md:w-auto"
              alt="youtube-icon"
              src={YoutubeIcon}
            />
          </a>
          <a target="_blank" href="https://twitter.com/gddesteken">
            <Image
              className="h-auto w-4 cursor-pointer  md:w-auto"
              alt="twitter-icon"
              src={TwitterIcon}
            />
          </a>
          <a target="_blank" href="https://www.instagram.com/gddestek.en/">
            <Image
              className="h-auto w-4 cursor-pointer  md:w-auto"
              alt="instagram-icon"
              src={InstaIcon}
            />
          </a>
          <a target="_blank" href="https://www.facebook.com/gddesteken">
            <Image
              className="h-auto w-4 cursor-pointer  md:w-auto"
              alt="facebook-icon"
              src={FacebookIcon}
            />
          </a>
        </div>
      </div>
    </div>
  );
}

export default FooterBottom;
