import React from "react";
import { ChevronIcon } from "../../icons";
import Image from "next/image";
import { useLocale } from "next-intl";

function SubscribeInput({ placeholder }: { placeholder: string }) {
  const locale = useLocale()
  return (
    <div className="flex max-w-[359px] items-center justify-between border-b border-b-darkGreen">
      <input
        className="w-full border-none bg-transparent py-2 text-xs text-darkGreen outline-none placeholder:text-xs placeholder:font-light placeholder:text-darkGreen"
        placeholder={placeholder}
      />
      <Image
        className={`h-auto w-auto cursor-pointer ${locale == "ar" ? "" : "rotate-180"}`}
        alt="chevron-icon"
        src={ChevronIcon}
      />
    </div>
  );
}

export default SubscribeInput;
