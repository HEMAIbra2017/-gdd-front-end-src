"use client"

import React from "react";
import FooterCard from "./FooterCard";
import ContactInfo from "./ContactInfo";
import FooterBottom from "./FooterBottom";
import { useTranslations } from "use-intl";

function Footer() {
  const t= useTranslations()
  return (
    <div className="bg-primary py-7 px-5 sm:px-10 lg:px-20 flex flex-col gap-y-12 ">
      <div className=" flex flex-col-reverse gap-y-4 xl:gap-y-0 xl:flex-row xl:items-center gap-x-8 center  justify-between">
        <FooterCard t={t}  />
        <ContactInfo t={t} />
      </div>
      <FooterBottom t={t} />
    </div>
  );
}

export default Footer;
