import PhoneIcon from "@/public/icons/phone.svg";
import LocationIcon from "@/public/icons/location.svg";
import MessageIcon from "@/public/icons/message.svg";
import FacebookIcon from "@/public/icons/facebook.svg";
import TwitterIcon from "@/public/icons/twitter.svg";
import InstaIcon from "@/public/icons/instaIcon.svg";
import YoutubeIcon from "@/public/icons/youtube.svg";

export { PhoneIcon, LocationIcon, MessageIcon, FacebookIcon, TwitterIcon, InstaIcon, YoutubeIcon };
