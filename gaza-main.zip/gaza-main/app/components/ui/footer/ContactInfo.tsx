import Image from "next/image";
import React from "react";
import { LocationIcon, MessageIcon, PhoneIcon } from "./icons";
import { useLocale } from "next-intl";
function ContactInfo({ t }: any) {
  const locale = useLocale();
  return (
    <div className=" flex flex-col  gap-y-6 text-white ">
      <div className="flex gap-x-2">
        <Image src={PhoneIcon} alt="phone-icon" className="mt-1 h-6 w-6" />
        <div className="flex flex-col">
          <h2 className="mb-1 text-xs font-semibold sm:text-sm">
            {t("Phone")}{" "}
          </h2>
          <a
            href="tel:+902126217973"
            dir="ltr"
            className="text-right  text-xs text-[#EEEEEE] sm:text-base"
          >
            +90 212 621 7973
          </a>
        </div>
      </div>
      <div className="flex gap-x-2">
        <Image src={MessageIcon} alt="message-icon" className="mt-1 h-6 w-6" />
        <div className="flex flex-col">
          <h2 className="mb-1 text-xs font-semibold sm:text-sm">
            {t("Email")}
          </h2>
          <a
            href="mailto: info@gdd.org"
            className=" text-xs text-[#EEEEEE] sm:text-base"
          >
            info@gdd.org
          </a>
        </div>
      </div>
      <div className="flex gap-x-2">
        <Image
          src={LocationIcon}
          alt="location-icon"
          className="mt-1 h-6 w-6"
        />
        <div className="flex flex-col">
          <h2 className="mb-1 text-xs font-semibold sm:text-sm">
            {t("Office Address")}
          </h2>
          <p
            dir="ltr"
            className={`${locale == "ar" ? "text-right" : "text-left"}  text-xs text-[#EEEEEE]  sm:text-base`}
          >
            Akşemsettin Mah. Akdeniz Cad. Hakperest sk. No:16 Daire:18 / Fatih –
            İSTANBUL
          </p>
        </div>
      </div>
    </div>
  );
}

export default ContactInfo;
