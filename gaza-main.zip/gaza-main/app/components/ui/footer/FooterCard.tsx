import React from "react";
import SubscribeInput from "./SubscribeInput";

function FooterCard({ t }: any) {
  return (
    <div className="flex max-w-[915px] flex-col gap-y-[15px] rounded-[6px] bg-white p-8  sm:p-12">
      <p className=" text-xs font-light leading-[18px] text-darkGreen  sm:text-sm sm:font-normal sm:leading-[21px]">
        {t("gdd_desc")}
      </p>
      <p className="text-xs font-semibold text-darkGreen  sm:text-base">
        {t("Subscribe to our newsletter to stay updated on our campaigns")}
      </p>
      <SubscribeInput placeholder={t("Email")} />
    </div>
  );
}

export default FooterCard;
