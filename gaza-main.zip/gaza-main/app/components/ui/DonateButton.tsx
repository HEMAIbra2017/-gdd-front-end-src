import getRedirectionUrls from "@/app/helpers/getRedirectionUrls";
import { useLocale } from "next-intl";
import React from "react";

function DonateButton({ t }: any) {
  const locale = useLocale();
  const { donateUrl } = getRedirectionUrls({ locale });

  return (
    <a
      href={donateUrl}
      target="_blank"
      className="primary_btn text-center text-sm"
    >
      {t("Donate Now")}
    </a>
  );
}

export default DonateButton;
