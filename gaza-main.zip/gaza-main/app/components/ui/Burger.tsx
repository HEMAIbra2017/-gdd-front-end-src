"use client";
import { usePathname, useRouter } from "@/navigation";

import Image from "next/image";
import React, { useEffect, useState } from "react";
import { BurgerIcon, CloseIcon, Logo } from "../icons";
import Navigation from "./Navigation";
import DonateButton from "./DonateButton";
import LoginButton from "./LoginButton";

function Burger({ t }: any) {
  const [show, setShow] = useState(false);
  const pathname = usePathname();
  const { push } = useRouter();

  useEffect(() => {
    setShow(false);
  }, [pathname]);

  useEffect(() => {
    if (show) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
  }, [show]);

  return (
    <div className="xl:hidden">
      <Image
        onClick={() => setShow(true)}
        alt="burger-icon"
        className="h-auto w-auto cursor-pointer"
        src={BurgerIcon}
      />
      {show ? (
        <div className=" fixed bottom-0 left-0 right-0 top-0 z-50 flex min-h-screen animate-fade flex-col overflow-auto bg-white scrollbar-hide">
          <div
            dir="rtl"
            className="flex  items-center justify-between border-b-[0.5px] border-b-[#8F8F8F] px-3 py-[27.45px] sm:py-[31.45px]"
          >
            <Image
              onClick={() => setShow(false)}
              src={CloseIcon}
              className=" h-auto w-auto cursor-pointer"
              alt="x-icon"
            />
            <Image
              className="h-[32px] w-[99px] cursor-pointer"
              onClick={() => {
                push("/");
                setShow(false);
              }}
              src={Logo}
              alt="logo-icon"
            />
          </div>
          <div className="px-3">
            <Navigation t={t} />
          </div>

          <div className="my-5 flex flex-col gap-y-3 px-3">
            <DonateButton t={t} />
            <LoginButton t={t} />
          </div>
        </div>
      ) : null}
    </div>
  );
}

export default Burger;
