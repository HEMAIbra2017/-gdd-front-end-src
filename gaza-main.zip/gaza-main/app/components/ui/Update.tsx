"use client"

import React from "react";
import { CloudUploadOutlined } from "@ant-design/icons";
import { useRouter } from "@/navigation";
import { getCookie } from "cookies-next";

function Update() {
  const role = getCookie("role")

  const { push } = useRouter();
  return (
    <div>
      {role == "admin" ? (
        <div className="fixed bottom-5 left-5 flex h-10 w-10 items-center justify-center rounded-full border-2 border-gray-500 bg-white p-3 shadow-lg ">
          <CloudUploadOutlined  onClick={() => push("/update")} />
        </div>
      ) : null}
    </div>
  );
}

export default Update;
