import Image from "next/image";
import React from "react";

function HeaderLastUpdated({
  last_updated: { time, date },
  t
}: {
  last_updated: { time: string; date: string };
  t:any
}) {
  return (
    <div className="flex flex-col items-center gap-x-[7px] text-[8px] font-semibold text-primary sm:text-xs min-w-fit">
      <div className="mb-[6px]">
        <Image
          src="/icons/calendar.svg"
          width={19}
          height={19}
          alt="calendar icon"
        />
      </div>
      <p className="mb-1 font-medium">{t("Updated on")}</p>
      <div className="font-medium sm:font-semibold text-center">
        <span>{date} - </span>
        <span>{time}</span>
      </div>
    </div>
  );
}

export default HeaderLastUpdated;
