import { Pagination } from "antd";
import { usePathname, useSearchParams, useRouter } from "next/navigation";
import React from "react";

function PaginationComponent({
  count,
  pageQueryName,
}: {
  count: number;
  pageQueryName?: string;
}) {
  const searchParams = useSearchParams();
  const params = new URLSearchParams(searchParams);
  const { push } = useRouter();
  const pathname = usePathname();

  const createPageURL = (pageNumber: number | string, name: string) => {
    params.set(name, pageNumber.toString());
    return `${pathname}?${params.toString()}`;
  };

  return (
    <Pagination
      showSizeChanger={false}
      current={Number(params.get(pageQueryName || "page")) || 1}
      total={count}
      pageSize={10}
      onChange={(page) => push(createPageURL(page, pageQueryName || "page"))}
    />
  );
}

export default PaginationComponent;
