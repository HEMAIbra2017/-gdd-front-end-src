import { useLocale } from "next-intl";
import { usePathname } from "@/navigation";
import React from "react";

function LangButton() {
  const pathname = usePathname();
  const locale = useLocale();

  const handleChangeLang = (e: any) => {
    const newLocale = e.target.value;
    const newPath = `/${newLocale}${pathname}`;
    const origin = window.location.origin;
    window.location.assign(`${origin}${newPath}`);
  };
  return (
    <>
      <select
        value={locale}
        onChange={handleChangeLang}
        className="hidden border border-none px-2 outline-none sm:block"
      >
        <option value="ar">عربي</option>
        <option value="en">EN</option>
        <option value="tr">TR</option>
        <option value="ID">ID</option>
      </select>
      <select
        value={locale}
        onChange={handleChangeLang}
        className="border border-none px-2 outline-none sm:hidden "
      >
        <option value="ar">ع</option>
        <option value="en">EN</option>
        <option value="tr">TR</option>
        <option value="ID">ID</option>
      </select>
    </>
  );
}

export default LangButton;
