"use client";

import { Link } from "@/navigation";
import { usePathname } from "@/navigation";
import React from "react";

const LinkItem = ({ text, href }: any) => {
  const pathname = usePathname();

  const isActive = pathname == href;
  return (
    <li
      className={`w-fit  text-center py-5 duration-200  hover:opacity-60 ${isActive ? "border-b-2  border-b-primary font-bold text-primary" : "border-b border-b-transparent"}`}
    >
      <Link href={href}>{text}</Link>
    </li>
  );
};

function Navigation({ t }: any) {
  return (
    <nav>
      <ul className="flex flex-col gap-x-5 xl:flex-row  xl:items-center   2xl:gap-x-8 ">
        <LinkItem text={t("Homepage")} href="/" />
        <LinkItem text={t("Damage Assessment")} href="/damages" />
        <LinkItem text={t("Required Interventions")} href="/actions" />
        <LinkItem text={t("Summary of Interventions")} href="/costs" />
        <LinkItem text={t("Achievements")} href="/achievements" />
        <LinkItem text={t("Gaza Strip")} href="/gaza" />
      </ul>
    </nav>
  );
}

export default Navigation;
