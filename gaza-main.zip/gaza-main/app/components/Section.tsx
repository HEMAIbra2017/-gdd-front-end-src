"use client";

import React from "react";

function Section({ title, children, id }: any) {
  return (
    <div id={id} className="px-2">
      <h2 className="text-3xl py-5 font-semibold">{title}</h2>
      <div className=" gap-2 grid grid-cols-1  sm:grid-cols-3 lg:grid-cols-6 xl:grid-cols-8 ">{children}</div>
    </div>
  );
}

export default Section;
