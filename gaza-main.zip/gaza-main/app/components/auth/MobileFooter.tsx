"use client";
import React from "react";
import SideContent from "./SideContent";

function MobileFooter({
  sideContent,
}: {
  sideContent: {
    title: string;
    subtitle?: string;
    btn: { text: string; action: () => void };
  };
}) {
  return (
    <div className=" relative h-[200px] w-full bg-auth bg-cover bg-center bg-no-repeat md:hidden ">
      <div className="  h-full bg-[#009971] bg-opacity-80">
        <SideContent {...sideContent} />
      </div>
    </div>
  );
}

export default MobileFooter;
