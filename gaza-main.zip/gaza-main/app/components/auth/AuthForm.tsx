"use client";

import React, { useState } from "react";
import { Button, Checkbox, Form, type FormProps, Input, message } from "antd";
import Image from "next/image";
import axios from "axios";
import { usePathname, useSearchParams } from "next/navigation";
import { setCookie } from "cookies-next";
import { useRouter } from "@/navigation";
import isObject from "@/app/helpers/isObject";
import { useLocale } from "next-intl";
type FieldType = {
  username?: string;
  email?: string;
  password?: string;
  remember?: string;
  password2?: string;
};

const onFinishFailed: FormProps<FieldType>["onFinishFailed"] = (
  errorInfo,
) => {};

const AuthForm = ({ content }: any) => {
  const pathname = usePathname();
  const { push } = useRouter();
  const [loading, setLoading] = useState(false);
  const searchParams = useSearchParams();

  const callback = searchParams.get("callback");
  const {
    title,
    pageName,
    form: {
      username,
      email,
      password,
      forgotPassword,
      confirmPassword,
      rememberMe,
      btn,
    },
  } = content;
  const [form] = Form.useForm();
  const locale = useLocale();
  const onFinish: FormProps<FieldType>["onFinish"] = (values) => {
    setLoading(true);
    axios
      .post(`/apis/${pageName}`, { locale, data: values })
      .then((res) => {
        if (res?.status == 200 || res?.status == 201) {
          const token = res?.data?.token;
          const role = res?.data?.role || "user";
          const messageText = res?.data?.message;
          if (messageText) {
            message.success(messageText);
          }
          if (token) {
            setCookie("token", token);
            setCookie("role", role);
            if (callback) {
              push(callback);
            } else {
              push("/");
            }
          }
        }
      })
      .catch((err) => {
        const errors = err?.response?.data;
        const messageText = errors?.message;

        if (messageText && typeof messageText == "string") {
          message.error(messageText);
        }
        if (errors && isObject(errors)) {
          form.setFields([
            {
              name: "username",
              errors: errors.username,
            },
            {
              name: "email",
              errors: errors.email,
            },
            {
              name: "password",
              errors: errors.password,
            },
            {
              name: "password2",
              errors: errors.password2,
            },
          ]);
        }
      })
      .finally(() => setLoading(false));
  };
  return (
    <>
      <h2 className="mb-6 border-b border-primary pb-4 text-sm font-semibold text-darkGreen md:text-xl ">
        {title}
      </h2>
      <Form
        form={form}
        name="login"
        // labelCol={{ span: 8 }}
        // wrapperCol={{ span: 16 }}
        style={{ width: "100%" }}
        initialValues={{ remember: true }}
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}
        autoComplete="off"
      >
        {username && (
          <Form.Item
            name="username"
            rules={[
              {
                required: true,
                message: "Please input your user name",
              },
            ]}
          >
            <Input
              placeholder={username?.text}
              prefix={
                <Image
                  src="/auth/user.svg"
                  alt="user-icon"
                  width={20}
                  height={17}
                />
              }
            />
          </Form.Item>
        )}

        <Form.Item
          name="email"
          rules={[
            {
              type: "email",
              message: "The input is not valid E-mail!",
            },
            {
              required: true,
              message: "Please input your E-mail!",
            },
          ]}
        >
          <Input
            placeholder={email?.text}
            prefix={
              <Image
                src="/auth/email.svg"
                alt="email-icon"
                width={20}
                height={17}
              />
            }
          />
        </Form.Item>

        <Form.Item<FieldType>
          name="password"
          rules={[
            { required: true, message: "Please input your password!" },
            // { min: 8 },
          ]}
        >
          <Input.Password
            placeholder={password?.text}
            prefix={
              <Image
                src="/auth/lock.svg"
                alt="password-icon"
                width={16}
                height={20}
              />
            }
          />
        </Form.Item>
        {confirmPassword && (
          <Form.Item
            name="password2"
            dependencies={["password"]}
            hasFeedback
            rules={[
              {
                required: true,
                message: "Please confirm your password!",
              },
              ({ getFieldValue }) => ({
                validator(_, value) {
                  if (!value || getFieldValue("password") === value) {
                    return Promise.resolve();
                  }
                  return Promise.reject(
                    new Error(
                      "The new password that you entered do not match!",
                    ),
                  );
                },
              }),
            ]}
          >
            <Input.Password
              prefix={
                <Image
                  src="/auth/lock.svg"
                  alt="password-icon"
                  width={16}
                  height={20}
                />
              }
              placeholder={confirmPassword?.text}
            />
          </Form.Item>
        )}

        {forgotPassword && rememberMe && (
          <div className="flex   justify-between">
            <Form.Item<FieldType> name="remember" valuePropName="checked">
              <Checkbox className=" !text-xs !font-light">
                {rememberMe?.text}{" "}
              </Checkbox>
            </Form.Item>
            <div className=" flex h-8 items-center justify-center !text-xs !font-light">
              {forgotPassword?.text}
            </div>
          </div>
        )}

        <Form.Item>
          <Button
            loading={loading}
            className="!md:text-base !h-fit !bg-primary !px-6  !py-3  !text-white"
            type="text"
            htmlType="submit"
          >
            {btn?.text}
          </Button>
        </Form.Item>
      </Form>
    </>
  );
};

export default AuthForm;
