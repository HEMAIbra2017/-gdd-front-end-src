import React from "react";
import AuthForm from "./AuthForm";
import SideContent from "./SideContent";

function AuthCard({ content }: any) {
  return (
    <div className=" relative w-full  overflow-hidden rounded-3xl border-[0.5px] border-primary bg-cover bg-center bg-no-repeat md:grid md:w-[721px] md:grid-cols-3 md:bg-auth">
      <div className=" pt:10 col-span-3  h-full  bg-[#E6F5F1]  px-8 md:px-12 pb-6 pt-10 md:col-span-2 md:pb-[129px] md:pt-[145px]">
        <AuthForm content={content} />
      </div>
      <div className=" hidden h-full bg-[#009971] bg-opacity-80 md:col-span-1 md:inline-grid ">
        <SideContent {...content.sideContent} />
      </div>
    </div>
  );
}

export default AuthCard;
