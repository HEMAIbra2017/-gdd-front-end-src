import React from "react";

function SideContent({
  title,
  subtitle,
  btn,
}: {
  title: string;
  subtitle?: string;
  btn: { text: string; action: () => void };
}) {
  return (
    <div className=" px-20 md:px-6 flex h-full flex-col items-center justify-center text-white">
      <h3 className="mb-2 text-sm md:text-base font-semibold">{title}</h3>
     {subtitle ? <p className="mb-4 text-xs font-light text-center  md:leading-[21.6px]">{subtitle}</p> : null} 
      <button
        className="rounded-lg bg-white px-4 py-2 text-xs md:text-sm font-semibold text-primary"
        onClick={btn.action}
      >
        {btn.text}
      </button>
    </div>
  );
}

export default SideContent;
