"use client";

import React from "react";
import TablePageLayout from "../../ui/TablePageLayout";
import { columns } from "./tableData";
import ActionsTables from "../actions/ActionsTables";
import { useTranslations } from "next-intl";

function AchievementsTable({data}:any) {
  const t=  useTranslations()
  return (
    <TablePageLayout text={t("Achievements")}>
      <ActionsTables t={t} data={data} columns={columns} />
    </TablePageLayout>
  );
}

export default AchievementsTable;
