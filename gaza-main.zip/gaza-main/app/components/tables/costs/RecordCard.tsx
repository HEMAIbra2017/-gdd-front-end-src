import formatNumber from "@/app/helpers/formatNumber";
import { useTranslations } from "next-intl";
import React from "react";

const CostItem = ({
  className,
  title,
  number,
}: {
  className: string;
  title: string;
  number: number;
}) => {
  return (
    <div className={`flex flex-col gap-y-1 rounded-lg p-2 ${className}`}>
      <h2>{title}</h2>
      <p>{formatNumber(number)}</p>
    </div>
  );
};

const CostsSummary = ({ record }: any) => {
  const t = useTranslations();

  return (
    <div className="flex flex-wrap items-center gap-2">
      <CostItem
        title={t("Relief")}
        number={record?.relief}
        className="border border-[#EB9F9F] bg-lightRed text-borderRed"
      />
      <CostItem
        title={t("Recovery")}
        number={record?.recovery}
        className="border border-[#94A2E9] bg-lightBlue text-[#152FBC]"
      />
      <CostItem
        title={t("Development")}
        number={record?.development}
        className="border border-[#9DE2AF] bg-lightGreen text-green2"
      />
      <CostItem
        title={t("Total")}
        number={record?.total}
        className="border border-black3 bg-[#EAEAEA] text-black3"
      />
    </div>
  );
};

const DataCard = ({
  title,
  subtitle,
  total,
}: {
  title: string;
  subtitle: any;
  total?: boolean;
}) => {
  return (
    <div
      className={`flex flex-col gap-y-2 rounded-2xl  p-4 text-xs   ${total ? "bg-primary text-white" : "bg-white text-darkGreen"}`}
    >
      <h2 className="  font-semibold"> {title}</h2>
      <p className="">
        {" "}
        {formatNumber(subtitle)}
      </p>
    </div>
  );
};

function RecordCard({ record }: { record: any }) {
  const t = useTranslations();
  return (
    <div className="flex flex-col gap-2 p-4 ">
      <DataCard
        title={t("Damage summary")}
        subtitle={record?.damage_summary || ""}
      />
      <DataCard
        title={t("Scope of Intervention")}
        subtitle={record?.scope_of_intervention || ""}
      />
      <DataCard
        title={t("Summary of Costs")}
        subtitle={<CostsSummary record={record} />}
      />
    </div>
  );
}

export default RecordCard;
