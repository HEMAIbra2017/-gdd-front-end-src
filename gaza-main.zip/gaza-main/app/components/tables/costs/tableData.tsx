import formatNumber from "@/app/helpers/formatNumber";
import { TableProps } from "antd";

export interface TotalDataType {
  data: {
    id: number;
    cost: DataType[];
    sector: string;
    relief: number;
    recovery: number;
    development: number;
    total: number;
  }[];
}

interface DataType {
  key: string;
  sub_sector?: string;
  damage_summary?: string;
  scope_of_intervention: string;
  relief: number;
  recovery: number;
  development: number;
  total: number;
}

export const columns = (t?: any): TableProps<DataType>["columns"] => {
  return [
    {
      title: t("Sub Sector"),
      dataIndex: "sub_sector",
      key: "sub_sector",
      width: 150,
    },
    {
      title: t("Damage summary"),
      dataIndex: "damage_summary",
      key: "damage_summary",
    },

    {
      title:t("Scope of Intervention"),
      key: "scope_of_intervention",
      dataIndex: "scope_of_intervention",
    },
    {
      title: t("Relief"),
      dataIndex: "relief",
      key: "relief",
      width: 100,
      render: (_, { relief }) => (
        <p className="font-semibold ">{formatNumber(relief)}</p>
      ),
    },
    {
      title: t("Recovery"),
      dataIndex: "recovery",
      key: "recovery",
      width: 100,
      render: (_, { recovery }) => (
        <p className="font-semibold ">{formatNumber(recovery)}</p>
      ),
    },
    {
      title: t("Development"),
      dataIndex: "development",
      key: "development",

      width: 100,

      render: (_, { development }) => (
        <p className="font-semibold ">{formatNumber(development)}</p>
      ),
    },

    {
      title: t("Total"),
      dataIndex: "total",
      width: 100,
      key: "total",
      render: (_, { total }) => (
        <p className="font-semibold ">{formatNumber(total)}</p>
      ),
    },
  ];
};
