"use client";

import React from "react";
import TablePageLayout from "../../ui/TablePageLayout";
import { Table } from "antd";
import { TotalDataType, columns } from "./tableData";
import RecordCard from "./RecordCard";
import { useTranslations } from "use-intl";
import formatNumber from "@/app/helpers/formatNumber";
import ExpandIcon from "../ui/ExpandIcon";
import TableChildrenWrapper from "@/app/components/tables/ui/TableChildrenWrapper";
const headersBgs: any = {
  3: "#4DA046",
  1: "#F99E2B",
  2: "#A31D44",
  4: "#16486D",
};
function CostsTable({ data }: TotalDataType) {
  const t = useTranslations();
  const totalRelief = data.reduce((a, b) => {
    return b.relief + a;
  }, 0);
  const totalDevelopment = data.reduce((a, b) => {
    return b.development + a;
  }, 0);
  const totalRecovery = data.reduce((a, b) => {
    return b.recovery + a;
  }, 0);
  const total = data.reduce((a, b) => {
    return b.total + a;
  }, 0);
  const rendredData = [3, 1, 2, 4].map((item) => {
    return data.find((ele) => ele?.id == item);
  });

  return (
    <TablePageLayout className=" mb-10" text={t("Summary of Interventions")}>
      <div className="flex flex-col gap-y-3">
        {rendredData?.map((item: any, index: number, arr: any) => {
          return (
            <>
              <Table
                key={item?.id}
                className="hidden xl:block"
                scroll={{ x: 992 }}
                pagination={false}
                expandable={{
                  childrenColumnName: "details",
                  expandRowByClick: true,
                  expandedRowRender: (record: any) => (
                    <TableChildrenWrapper>
                      <RecordCard record={record} />
                    </TableChildrenWrapper>
                  ),
                  expandIcon: ({
                    expanded,
                    record,
                    onExpand,
                  }: {
                    expanded: boolean;
                    record: any;
                    onExpand: any;
                  }) => (
                    <ExpandIcon
                      expanded={expanded}
                      record={record}
                      onExpand={onExpand}
                    />
                  ),
                }}
                title={() => (
                  <div
                    style={{ backgroundColor: `${headersBgs[item?.id]}` }}
                    className={` table-title `}
                  >
                    {item?.sector}{" "}
                  </div>
                )}
                summary={() => (
                  <>
                    <Table.Summary fixed>
                      <Table.Summary.Row>
                        <Table.Summary.Cell index={1} className="!p-0">
                          <div
                            className="p-4 text-transparent"
                            style={{
                              backgroundColor: `${headersBgs[item?.id]}`,
                              borderRadius: "inherit",
                            }}
                          >
                            -
                          </div>
                        </Table.Summary.Cell>
                        <Table.Summary.Cell
                          index={0}
                          className={` !p-0 font-semibold text-white`}
                        >
                          <div
                            className="p-4"
                            style={{
                              backgroundColor: `${headersBgs[item?.id]}`,
                              borderRadius: "inherit",
                            }}
                          >
                            {t("Subtotal")}
                          </div>
                        </Table.Summary.Cell>
                        <Table.Summary.Cell index={1} className="!p-0">
                          <div
                            className="p-4 text-transparent"
                            style={{
                              backgroundColor: `${headersBgs[item?.id]}`,
                              borderRadius: "inherit",
                            }}
                          >
                            -
                          </div>
                        </Table.Summary.Cell>
                        <Table.Summary.Cell index={2} className={`!p-0`}>
                          <div
                            className="p-4 text-transparent"
                            style={{
                              backgroundColor: `${headersBgs[item?.id]}`,
                              borderRadius: "inherit",
                            }}
                          >
                            -
                          </div>
                        </Table.Summary.Cell>
                        <Table.Summary.Cell
                          index={3}
                          className={` !p-0 font-semibold  text-white`}
                        >
                          <div
                            className="p-4"
                            style={{
                              backgroundColor: `${headersBgs[item?.id]}`,
                              borderRadius: "inherit",
                            }}
                          >
                            {formatNumber(item?.relief)}
                          </div>
                        </Table.Summary.Cell>
                        <Table.Summary.Cell
                          index={4}
                          className="!p-0 font-semibold text-white "
                        >
                          <div
                            className="p-4"
                            style={{
                              backgroundColor: `${headersBgs[item?.id]}`,
                              borderRadius: "inherit",
                            }}
                          >
                            {formatNumber(item?.recovery)}
                          </div>
                        </Table.Summary.Cell>
                        <Table.Summary.Cell
                          index={5}
                          className="!p-0 font-semibold text-white "
                        >
                          <div
                            className="p-4"
                            style={{
                              backgroundColor: `${headersBgs[item?.id]}`,
                              borderRadius: "inherit",
                            }}
                          >
                            {formatNumber(item?.development)}
                          </div>
                        </Table.Summary.Cell>
                        <Table.Summary.Cell
                          index={7}
                          className="!p-0 font-semibold text-white "
                        >
                          <div
                            className="p-4"
                            style={{
                              backgroundColor: `${headersBgs[item?.id]}`,
                              borderRadius: "inherit",
                            }}
                          >
                            {formatNumber(item?.total)}
                          </div>
                        </Table.Summary.Cell>
                      </Table.Summary.Row>
                    </Table.Summary>
                    {index == arr.length - 1 ? (
                      <Table.Summary fixed>
                        <Table.Summary.Row>
                          <Table.Summary.Cell
                            index={2}
                            className="bg-[#4d4d4d] "
                          >
                            {" "}
                          </Table.Summary.Cell>
                          <Table.Summary.Cell
                            index={0}
                            className="bg-[#4d4d4d] font-semibold text-white"
                          >
                            {t("Total")}
                          </Table.Summary.Cell>
                          <Table.Summary.Cell
                            index={1}
                            className="bg-[#4d4d4d] "
                          ></Table.Summary.Cell>
                          <Table.Summary.Cell
                            index={2}
                            className="bg-[#4d4d4d] "
                          >
                            {" "}
                          </Table.Summary.Cell>
                          <Table.Summary.Cell
                            index={3}
                            className="bg-[#4d4d4d] font-semibold text-white "
                          >
                            {formatNumber(totalRelief)}
                          </Table.Summary.Cell>
                          <Table.Summary.Cell
                            index={4}
                            className="bg-[#4d4d4d] font-semibold text-white "
                          >
                            {formatNumber(totalRecovery)}
                          </Table.Summary.Cell>
                          <Table.Summary.Cell
                            index={5}
                            className="bg-[#4d4d4d] font-semibold text-white "
                          >
                            {formatNumber(totalDevelopment)}
                          </Table.Summary.Cell>
                          <Table.Summary.Cell
                            index={7}
                            className="bg-[#4d4d4d] font-semibold text-white "
                          >
                            {formatNumber(total)}
                          </Table.Summary.Cell>
                        </Table.Summary.Row>
                      </Table.Summary>
                    ) : null}
                  </>
                )}
                dataSource={item?.cost}
                columns={columns(t)}
              />
              <Table
                showHeader={false}
                className="xl:hidden"
                key={item?.title}
                pagination={false}
                expandable={{
                  childrenColumnName: "details",
                  expandRowByClick: true,
                  expandedRowRender: (record: any) => (
                    <TableChildrenWrapper>
                      <RecordCard record={record} />
                    </TableChildrenWrapper>
                  ),
                  expandIcon: ({
                    expanded,
                    record,
                    onExpand,
                  }: {
                    expanded: boolean;
                    record: any;
                    onExpand: any;
                  }) => (
                    <ExpandIcon
                      expanded={expanded}
                      record={record}
                      onExpand={onExpand}
                    />
                  ),
                }}
                title={() => (
                  <div
                    style={{ backgroundColor: `${headersBgs[item?.id]}` }}
                    className={` table-title `}
                  >
                    {item?.sector}{" "}
                  </div>
                )}
                summary={() => (
                  <>
                    <Table.Summary fixed>
                      <Table.Summary.Row>
                        <Table.Summary.Cell
                          index={0}
                          className={` !p-0 font-semibold text-white`}
                        >
                          <div
                            className=" p-4 text-transparent"
                            style={{
                              backgroundColor: `${headersBgs[item?.id]}`,
                              borderRadius: "inherit",
                            }}
                          >
                            -
                          </div>
                        </Table.Summary.Cell>
                        <Table.Summary.Cell
                          index={0}
                          className={` !p-0 font-semibold text-white`}
                        >
                          <div
                            className="flex items-center justify-between p-4"
                            style={{
                              backgroundColor: `${headersBgs[item?.id]}`,
                              borderRadius: "inherit",
                            }}
                          >
                            <div className="whitespace-nowrap">
                              {t("Subtotal")}
                            </div>
                            <div> {formatNumber(item?.total)}</div>
                          </div>
                        </Table.Summary.Cell>
                      </Table.Summary.Row>
                    </Table.Summary>
                    {index == arr.length - 1 ? (
                      <Table.Summary fixed>
                        <Table.Summary.Row>
                          <Table.Summary.Cell
                            index={0}
                            className="bg-[#272727] font-semibold text-transparent"
                          >
                            -
                          </Table.Summary.Cell>
                          <Table.Summary.Cell
                            index={0}
                            className="flex items-center justify-between bg-[#272727] font-semibold text-white"
                          >
                            <div className="whitespace-nowrap">
                              {" "}
                              {t("Total")}
                            </div>
                            <div> {formatNumber(total)}</div>
                          </Table.Summary.Cell>
                        </Table.Summary.Row>
                      </Table.Summary>
                    ) : null}
                  </>
                )}
                dataSource={item?.cost}
                columns={columns(t)?.slice(0, 1)}
              />
            </>
          );
        })}
      </div>
    </TablePageLayout>
  );
}

export default CostsTable;
