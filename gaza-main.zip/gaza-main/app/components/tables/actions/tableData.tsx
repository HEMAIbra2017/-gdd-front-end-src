import { TableProps } from "antd";
import Tags from "../ui/Tags";
import formatNumber from "@/app/helpers/formatNumber";

export type DataType = {
  key: string;
  damage?: string;
  sub_sector?: string;
  subclassification?: string;
  tags?: string[];
  total_estimation: number;
  action_type?: string;
  target_number: number;
  action_value: number;
  total: number;
  children?: DataType[];
};

export const columns = (t?: any): TableProps<DataType>["columns"] => {
  return [
    {
      title: t("Damages"),
      dataIndex: "damage",
      key: "damage",
      width: 200,
    },
    {
      title: t("Sub Sector"),
      dataIndex: "sub_sector",
      key: "sub_sector",
    },
    {
      title: t("Sub Classification"),
      dataIndex: "subclassification",
      key: "subclassification",
    },

    {
      title: t("Type of Value / Scope"),
      key: "tags",
      dataIndex: "tags",
      width: 130,

      render: (_, { tags }) => <Tags tags={tags} />,
    },
    {
      title: t("Damage Estimate"),
      dataIndex: "total_estimation",
      key: "total_estimation",
      width: 121,
      render: (_, { total_estimation }) => (
        <p className="font-semibold ">
          {formatNumber(total_estimation)}
        </p>
      ),
    },
    {
      title: t("Type of intervention"),
      dataIndex: "action_type",
      width: 121,
      key: "action_type",
    },
    {
      title: t("Required quantity"),
      dataIndex: "target_number",
      key: "target_number",
      width: 121,
      render: (_, { target_number }) => (
        <p className="font-semibold ">
          {formatNumber(target_number)}
        </p>
      ),
    },
    {
      title: t("Cost of Intervention"),
      dataIndex: "action_value",
      key: "action_value",
      width: 121,
      render: (_, { action_value }) => (
        <p className="font-semibold ">
          {formatNumber(action_value)}
        </p>
      ),
    },
    {
      title: t("Total"),
      dataIndex: "total",
      key: "total",
      width: 140,
      render: (_, { total }) => (
        <p className="font-semibold ">
          {formatNumber(total)}
        </p>
      ),
    },
  ];
};
