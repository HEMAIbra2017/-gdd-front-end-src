"use client";
import React from "react";
import MainTable from "./MainTable";
import MobileTable from "./MobileTable";
import PaginationComponent from "../../ui/PaginationComponent";
function ActionsTables({ columns, data, t }: any) {
  return (
    <div className="flex flex-col gap-y-10">
      {data?.map(({ title: {  className }, name, sectionData }: any) => (
        <>
          <MainTable
            title={() => (
              <div className={`table-title ${className}`}>
                {sectionData?.results?.[0]?.sector}
              </div>
            )}
            dataSource={sectionData?.results}
            columns={columns(t)}
          />

          <MobileTable
            title={() => (
              <div className={`table-title ${className}`}>
                {sectionData?.results?.[0]?.sector}
              </div>
            )}
            dataSource={sectionData?.results}
            columns={columns(t)}
          />
          <PaginationComponent
            count={sectionData?.count}
            pageQueryName={name}
          />
        </>
      ))}
    </div>
  );
}

export default ActionsTables;
