import { Table } from "antd";
import React from "react";
import { rowClassName } from "./helpers/rowClassName";
import ExpandIcon from "../ui/ExpandIcon";
import TableChildrenWrapper from "@/app/components/tables/ui/TableChildrenWrapper";

function MainTable({ dataSource, columns, title }: any) {
  return (
    <Table
      className="hidden xl:block "
      scroll={{ x: 1300 }}
      title={title}
      dataSource={dataSource}
      columns={columns}
      pagination={false}
      rowClassName={(record) => `colored ${rowClassName(record?.tags)}`}
      expandable={{
        childrenColumnName: "details",
        rowExpandable: (record: any) => record?.children?.length > 0,
        expandedRowClassName: () => {
          return "transparent_bg";
        },
        expandedRowRender: (record) => (
          <TableChildrenWrapper>
            <Table
              rowClassName={(record) => `colored ${rowClassName(record?.tags)}`}
              className="child_table"
              showHeader={false}
              dataSource={record?.children}
              columns={columns}
              pagination={false}
            />
          </TableChildrenWrapper>
        ),
        expandRowByClick: true,
        expandIcon: ({
          expanded,
          record,
          onExpand,
        }: {
          expanded: boolean;
          record: any;
          onExpand: any;
        }) =>
          record?.children?.length > 0 ? (
            <ExpandIcon
              expanded={expanded}
              record={record}
              onExpand={onExpand}
            />
          ) : null,
      }}
    />
  );
}

export default MainTable;
