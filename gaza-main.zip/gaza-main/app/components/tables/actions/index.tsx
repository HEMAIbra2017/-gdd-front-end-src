"use client";

import React from "react";
import TablePageLayout from "../../ui/TablePageLayout";
import { columns } from "./tableData";
import ActionsTables from "./ActionsTables";
import { useTranslations } from "next-intl";
function ActionsTable({ data }: { data: any }) {
  const t = useTranslations();

  return (
    <TablePageLayout text={t("Required Interventions")}>
      <ActionsTables t={t} data={data} columns={columns} />
    </TablePageLayout>
  );
}

export default ActionsTable;
