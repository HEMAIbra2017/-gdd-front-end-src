import { Table } from "antd";
import React, { ReactNode } from "react";
import RecordCard from "./RecordCard";
import { rowClassName } from "./helpers/rowClassName";
import ExpandIcon from "../ui/ExpandIcon";
import TableChildrenWrapper from "@/app/components/tables/ui/TableChildrenWrapper";

function MobileTable({
  title,
  dataSource,
  columns,
}: {
  title: any;
  dataSource: any;
  columns: any;
}) {
  const expandable = {
    childrenColumnName: "details",
    rowExpandable: (record: any) => record.children.length > 0,
    expandedRowClassName: () => {
      return "transparent_bg";
    },
    expandRowByClick: true,
    // fixed: true,
    expandIcon: ({
      expanded,
      record,
      onExpand,
    }: {
      expanded: boolean;
      record: any;
      onExpand: any;
    }) =>
      record?.children?.length > 0 ? (
        <ExpandIcon expanded={expanded} record={record} onExpand={onExpand} />
      ) : null,
    expandedRowRender: (record: any) => (
      <TableChildrenWrapper>
        <RecordCard record={record} />
      </TableChildrenWrapper>
    ),
  };
  return (
    <Table
      rowClassName={(record) => `colored ${rowClassName(record?.tags)}`}
      className="xl:hidden"
      title={title}
      expandable={expandable}
      dataSource={dataSource}
      columns={columns?.slice(0, 1)}
      showHeader={false}
      pagination={false}
    />
  );
}

export default MobileTable;
