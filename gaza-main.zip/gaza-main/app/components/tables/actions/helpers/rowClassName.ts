export function rowClassName(tags: any) {
  return tags?.includes("relief")
    ? "relief"
    : tags?.includes("recovery")
      ? "recovery"
      : tags?.includes("develop")
        ? "develop"
        : "";
}
