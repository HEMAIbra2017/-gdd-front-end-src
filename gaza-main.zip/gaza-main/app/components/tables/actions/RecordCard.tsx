import React from "react";
import Tags from "../ui/Tags";
import { rowClassName } from "./helpers/rowClassName";
import { useTranslations } from "next-intl";
import formatNumber from "@/app/helpers/formatNumber";

const bgColor: any = {
  relief: "bg-lightRed",
  recovery: "bg-lightBlue",
  develop: "bg-lightGreen",
};
const totalBg: any = {
  relief: "bg-red3",
  recovery: "bg-[#102593]",
  develop: "bg-[#27AE49]",
};
const borderColor: any = {
  relief: "border-[0.5px] border-borderRed",
  recovery: "border-[0.5px] border-borderBlue",
  develop: "border-[0.5px] border-borderGreen",
};

const DataCard = ({
  title,
  subtitle,
  tags,
  bg,
}: {
  title: string;
  subtitle: any;
  tags?: any;
  bg?: string;
}) => {
  return (
    <div
      className={`flex flex-col gap-y-1 rounded-2xl ${borderColor[rowClassName(tags)]}   p-4 text-xs  ${bg ? `${bg} text-white` : "bg-white text-black3"}`}
    >
      <h2 className="  font-semibold"> {title}</h2>
      <p className="">
        {" "}
        {formatNumber(subtitle)}
      </p>
    </div>
  );
};
const HeaderCard = ({ title, subtitle }: { title: string; subtitle: any }) => {
  return (
    <div className={`flex flex-col gap-y-2 rounded-2xl text-xs  `}>
      <h2 className="  text-center text-[8px] font-light text-darkGreen">
        {" "}
        {title}
      </h2>
      <div className="rounded-lg bg-[#183938] px-1 py-4 text-center text-[11px] font-light text-white">
        {" "}
        {formatNumber(subtitle)}
      </div>
    </div>
  );
};

const DetailsData = ({ data }: any) => {
  const t = useTranslations();
  return (
    <div
      className={` mt-2 grid grid-cols-2 gap-2 rounded-2xl  p-4 ${borderColor[rowClassName(data?.tags)]}  ${bgColor[rowClassName(data?.tags)]}`}
    >
      <DataCard
        tags={data?.tags}
        title={t("Type of Value / Scope")}
        subtitle={<Tags tags={data?.tags} /> || ""}
      />
      <DataCard
        tags={data?.tags}
        title={t("Damage Estimate")}
        subtitle={data?.total_estimation || ""}
      />
      <DataCard
        tags={data?.tags}
        title={t("Type of intervention")}
        subtitle={data?.action_type || ""}
      />
      <DataCard
        tags={data?.tags}
        title={t("Required quantity")}
        subtitle={data?.target_number || ""}
      />
      <DataCard
        tags={data?.tags}
        title={t("Cost of Intervention")}
        subtitle={data?.action_value || ""}
      />
      {data?.completed ? (
        <DataCard
          tags={data?.tags}
          title={t("Progress Achieved")}
          subtitle={data?.completed || ""}
        />
      ) : null}
      {data?.completion_rate ? (
        <DataCard
          tags={data?.tags}
          title={t("Percentage of Completion")}
          subtitle={data?.completion_rate || ""}
        />
      ) : null}

      <DataCard
        bg={totalBg[rowClassName(data?.tags)]}
        title={t("Total")}
        subtitle={data?.total || ""}
        tags={data?.tags}
      />
    </div>
  );
};

function RecordCard({ record }: { record: any }) {
  const t = useTranslations();

  return (
    <div className="flex flex-col gap-y-2 rounded-2xl border-[0.5px] border-[#9D9D9D] !bg-lightGray px-2 py-4 sm:px-4">
      <div className="grid grid-cols-2 gap-2">
        <HeaderCard
          title={t("Sub Sector")}
          subtitle={record?.sub_sector || ""}
        />
        <HeaderCard
          title={t("Sub Classification")}
          subtitle={record?.subclassification || ""}
        />
      </div>

      <DetailsData data={record} />
      {record?.children?.map((child: any) => (
        <DetailsData key={child.key} data={child} />
      ))}
    </div>
  );
}

export default RecordCard;
