import Image from "next/image";
import React from "react";

function Hide({ onClick }: any) {
  return (
    <div className="h-4 w-4">
      <Image
        className="hide-icon  cursor-pointer"
        onClick={onClick}
        width={16}
        height={16}
        src="/icons/hide.svg"
        alt="expand icon"
      />
    </div>
  );
}

export default Hide;
