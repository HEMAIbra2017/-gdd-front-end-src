import React from "react";
import Hide from "./Hide";
import Expand from "./Expand";

function ExpandIcon({ expanded, record, onExpand }: any) {
  return (
    <>
      {expanded ? (
        <Hide onClick={(e: any) => onExpand(record, e)} />
      ) : (
        <Expand onClick={(e: any) => onExpand(record, e)} />
      )}
    </>
  );
}

export default ExpandIcon;
