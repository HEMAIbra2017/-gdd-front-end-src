import { Tag } from "antd";
import { useTranslations } from "next-intl";
import React from "react";

function Tags({ tags }: any) {
  const t = useTranslations()
  return (
    <div className="w-[130px]">
      {tags &&
        tags.map((tag: any) => {
          let color;
          if (tag == "relief") {
            color = "red";
          } else if (tag == "recovery") {
            color = "blue";
          } else if (tag == "develop") {
            color = "green";
          } else {
            color = "default";
          }

          return (
            <Tag color={color} key={tag}>
              {tag == "number"
                ? t("Number")
                : tag == "relief"
                  ? t("Relief")
                  : tag == "recovery"
                    ? t("Recovery")
                    : tag == "develop"
                      ? t("Development")
                      : tag == "percentage"
                        ? t("Percentage")
                        : tag == "total_value"
                          ? t("Total value")
                          : ""}
            </Tag>
          );
        })}
    </div>
  );
}

export default Tags;
