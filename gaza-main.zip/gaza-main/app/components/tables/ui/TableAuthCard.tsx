import React from "react";
import UserIcon from "@/public/icons/user.svg";
import Image from "next/image";
import { twMerge } from "tailwind-merge";
import { useTranslations } from "next-intl";
import { redirect, usePathname, useRouter } from "@/navigation";
function TableAuthCard() {
  const t = useTranslations();
  const pathname = usePathname();
  const {push} = useRouter();

  return (
    <div className="absolute z-10 left-1/2 top-5 flex w-[90%] -translate-x-1/2 flex-col items-center  gap-y-5 rounded-2xl border-gray6 bg-white px-8 pb-10 pt-11 text-black shadow-[0_0_36px_0_#0000002E] sm:w-auto">
      <Image src={UserIcon} className="h-auto w-8 sm:w-auto" alt="user-icon" />
      <p className="s:text-base text-center text-xs sm:text-inherit">
        {"لاستعراض التفاصيل يرجى تسجيل الدخول باسم المستخدم"}
      </p>
      <div className="flex flex-col items-center gap-x-5 gap-y-2 md:flex-row md:gap-y-0">
        <button
          onClick={() => push(`/auth/register?callback=${pathname}`)}
          className={twMerge(
            `primary_btn`,
            "border border-primary px-4 py-2 text-xs",
          )}
        >
          {t("Create a New Account")}
        </button>
        <button
          onClick={() =>push(`/auth/login?callback=${pathname}`)}
          className={"secondary_btn"}
        >
          {t("Login")}
        </button>
      </div>
    </div>
  );
}

export default TableAuthCard;
