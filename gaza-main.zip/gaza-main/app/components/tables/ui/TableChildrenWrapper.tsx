import { getCookie } from "cookies-next";
import { ReactNode } from "react";
import TableAuthCard from "./TableAuthCard";

export default function TableChildrenWrapper({
  children,
}: {
  children: ReactNode;
}) {
  const token = getCookie("token");

  // if (token) {
  return <div style={{ margin: 0 }}>{children}</div>;
  // }

  // return (
  //   <div className="relative" style={{ margin: 0 }}>
  //     <div className="blur-sm pointer-events-none select-none min-h-[260px]">{children}</div>
  //     <TableAuthCard />
  //   </div>
  // );
}
