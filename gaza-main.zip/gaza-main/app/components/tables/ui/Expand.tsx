import Image from "next/image";
import React from "react";

function Expand({ onClick }: { onClick?: any }) {
  return (
    <div className="w-4 h-4">
      <Image
        className="expand-icon cursor-pointer"
        onClick={onClick ? onClick : () => {}}
        width={16}
        height={16}
        src="/icons/expand.svg"
        alt="hide icon"
      />
    </div>
  );
}

export default Expand;
