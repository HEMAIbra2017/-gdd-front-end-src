import formatNumber from "@/app/helpers/formatNumber";
import { TableProps } from "antd";
interface DataType {
  key: number;
  damage?: string;
  sub_sector?: string;
  sub_classification?: string;
  damage_value_number: number;
  damage_value_percentage: string;
  updated_at: string;
  cards: any;
}
interface MobileDataType {
  key: string;
  sub_classification?: string;
  sub_sector?: string;
  damage_value_number: number;
  cards: any;
}

export const MobileColumns = (
  t?: any,
): TableProps<MobileDataType>["columns"] => {
  return [
    {
      title: t("Sub Classification"),
      dataIndex: "sub_classification",
      key: "sub_classification",
      render: (_, { sub_classification }) => (
        <p className="text-xs sm:text-sm">{sub_classification || "---"}</p>
      ),
    },

    {
      title: t("Sub Sector"),
      dataIndex: "sub_sector",
      key: "sub_sector",
      render: (_, { sub_sector }) => (
        <p className="text-[10px] sm:text-sm">{sub_sector}</p>
      ),
    },

    {
      title: t("Damage Estimate"),
      dataIndex: "damage_value_number",
      key: "damage_value_number",
      width: 121,
      render: (_, { damage_value_number }) => (
        <p className="text-xs font-semibold sm:text-sm ">
          {formatNumber(damage_value_number)}
        </p>
      ),
    },
  ];
};
export const columns = (t?: any): TableProps<DataType>["columns"] => {
  return [
    {
      title: t("Sub Classification"),
      dataIndex: "sub_classification",
      key: "sub_classification",
      render: (_, { sub_classification }) => (
        <p>{sub_classification || "---"}</p>
      ),
    },
    {
      title: t("Damages"),
      dataIndex: "damage",
      key: "damage",
      render: (_, { damage }) => <p>{damage}</p>,
    },
    {
      title: t("Sub Sector"),
      dataIndex: "sub_sector",
      key: "sub_sector",
      render: (_, { sub_sector }) => (
        <p className="text-[10px] sm:text-sm">{sub_sector}</p>
      ),
    },

    {
      title: t("Damage Estimate"),
      dataIndex: "damage_value_number",
      key: "damage_value_number",
      width: 121,
      render: (_, { damage_value_number }) => (
        <p className="text-xs font-semibold sm:text-sm ">
          {formatNumber(damage_value_number)}
        </p>
      ),
    },
    {
      title: t("Percentage"),
      dataIndex: "damage_value_percentage",
      width: 121,
      key: "damage_value_percentage",
      render: (_, { damage_value_percentage }) => (
        <p className="text-xs font-semibold sm:text-sm ">
          {damage_value_percentage}
        </p>
      ),
    },
    {
      title: t("Updated on"),
      dataIndex: "target_number",
      key: "updated_at",
      width: 121,
      render: (_, { updated_at }) => <p className="">{updated_at || "---"}</p>,
    },
  ];
};
