import formatNumber from "@/app/helpers/formatNumber";
import React from "react";

function Details({ data }: any) {
  return (
    <div className="flex flex-col gap-y-4">
      <h2 className="font-bold">{data?.title}</h2>
      <div className="flex flex-wrap gap-y-6    gap-x-4">
        {data?.data?.map((item: any, index: number) => (
          <div key={index} className="flex flex-col">
            <p className="text-xs">{item?.title}</p>
            <p className="text-[28px] font-bold ">
              {formatNumber(item?.number)}
            </p>

            <p className=" font-light text-xs">{item?.percentage}</p>
          </div>
        ))}
      </div>

      <div></div>
    </div>
  );
}

export default Details;
