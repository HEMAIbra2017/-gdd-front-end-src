import React from "react";
import IconsCards from "./cards/IconsCards";
import PieChartCard from "./cards/PieChartCard";
import BarChart from "./cards/BarChart";

type CardsProps = {
  title: string;
  charts: {
    type: string;
    data: any;
  }[];
}[];

const getCard = (chart: any) => {
  const cards: any = {
    icon: <IconsCards data={chart?.data} />,
    piechart: <PieChartCard data={chart?.data} />,
    barchart: <BarChart data={chart?.data} />,
  };

  return cards[chart?.type];
};

function DamageDetailsCard({ data }: { data: CardsProps }) {
  return (
    <div className=" flex flex-col gap-2 p-4 lg:grid  lg:grid-cols-2 ">
      {data?.map((card, index) => {
        return (
          <>
            {card?.charts?.map((chart, index) => {
              return (
                <div
                  className="flex flex-col gap-y-4 rounded-2xl border-[0.5px] border-[#8AD0BE] bg-white p-4"
                  key={index}
                >
                  <h3 className="text-xs text-darkGreen">{card?.title}</h3>

                  {getCard(chart)}
                </div>
              );
            })}
          </>
        );
      })}
    </div>
  );
}

export default DamageDetailsCard;
