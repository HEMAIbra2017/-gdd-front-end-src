const colors =[
    "#009971",
    "#00543E",
    "#CAAE7C",
    "#16486D",
    "#6F6044",
    "#183938",
    "#2B6766",
  ];

export default function getColors(index?: number) {
  return index
    ? colors.slice(0, index)
    : colors;
}
