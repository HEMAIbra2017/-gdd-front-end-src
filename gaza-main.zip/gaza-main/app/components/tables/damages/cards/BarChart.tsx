"use client";

import dynamic from "next/dynamic";
import React from "react";
import getColors from "../helpers/getColors";
const Chart = dynamic(() => import("react-apexcharts"), { ssr: false });
function BarChart({ data }: any) {
  const barHeight = 20;
  const totalBarsHeight = +data.length * barHeight;
  return (
    <div dir="ltr" className="">
      <Chart
        height={totalBarsHeight + barHeight * 7}
        width="100%"
        options={{
          chart: {
            id: "basic-bar",

            // defaultLocale: "ar",
            // locales: [
            //   {
            //     name: "ar",
            //     options: {
            //       months: [
            //         "January",
            //         "February",
            //         "March",
            //         "April",
            //         "May",
            //         "June",
            //         "July",
            //         "August",
            //         "September",
            //         "October",
            //         "November",
            //         "December",
            //       ],
            //       shortMonths: [
            //         "Jan",
            //         "Feb",
            //         "Mar",
            //         "Apr",
            //         "May",
            //         "Jun",
            //         "Jul",
            //         "Aug",
            //         "Sep",
            //         "Oct",
            //         "Nov",
            //         "Dec",
            //       ],
            //       days: [
            //         "Sunday",
            //         "Monday",
            //         "Tuesday",
            //         "Wednesday",
            //         "Thursday",
            //         "Friday",
            //         "Saturday",
            //       ],
            //       shortDays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
            //       toolbar: {
            //         download: "تحميل ك SVG",
            //         selection: "Selection",
            //         selectionZoom: "Selection Zoom",
            //         zoomIn: "Zoom In",
            //         zoomOut: "Zoom Out",
            //         pan: "Panning",
            //         reset: "Reset Zoom",
            //       },
            //     },
            //   },
            // ],
          },
          xaxis: {
            min: 0,
            max: data?.item?.[0]?.data_type == "percentage" ? 100 : undefined,
            labels: {
              style: {
                fontFamily: "var(--font-primary)",
                fontSize: "8px",
                fontWeight: "300",
                colors: ["#00543E"],
              },
            },
          },

          yaxis: {
            // reversed: true,

            labels: {
              show: true,
              align: "center",
              minWidth: 0,
              style: {
                fontFamily: "var(--font-primary)",
                fontSize: "8px",
                fontWeight: "500",
                colors: ["#00543E"],
              },

              offsetY: 0,
              rotate: 0,
            },
          },
          plotOptions: {
            bar: {
              borderRadius: 2,
              horizontal: true,
              barHeight: barHeight,
            },
          },
          dataLabels: {
            formatter: (val, opts) => {
              const dataPointIndex = opts?.dataPointIndex;
              const seriesData = data[dataPointIndex];
              const text =
                seriesData?.data_type == "number"
                  ? `(${seriesData?.percentage})`
                  : seriesData?.data_type == "percentage"
                    ? `(${seriesData?.number})`
                    : "";
              const value = typeof val == "number" ? val.toLocaleString() : val;
              return `${value} ${text}`;
            },
            enabled: true,
            textAnchor: "start",
            style: {
              colors: ["#181818"],
              fontWeight: "400",
            },
            // offsetX: 40,
            background: {
              enabled: true,
              foreColor: "#FFF",
            },
          },
        }}
        series={[
          {
            name: "",
            data: data?.map((item: any, index: number) => ({
              x: item?.name,
              y:
                item?.data_type == "number"
                  ? parseInt(item?.number)
                  : item?.percentage,
              fillColor: getColors()[index],
            })),
          },
        ]}
        type="bar"
      />
    </div>
  );
}

export default BarChart;
