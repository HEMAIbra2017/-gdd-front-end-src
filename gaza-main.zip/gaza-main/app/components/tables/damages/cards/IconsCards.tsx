import formatNumber from "@/app/helpers/formatNumber";
import Image from "next/image";
import React from "react";

type DataProps = {
  image?: string;
  name: string;
  number: number;
  percentage: string;
  data_type?: string;
}[];

function IconsCards({ data }: { data: DataProps }) {
  return (
    <div className="flex flex-wrap  gap-6 text-primary">
      {data?.map((item, index) => (
        <div key={index} className="flex flex-col gap-y-1">
          {item?.image ? (
            <Image width={24} height={24} src={item.image} alt="icon" />
          ) : null}
          <p className="text-[10px] font-light text-darkGreen">{item.name}</p>
          <p className="text-xl font-semibold leading-[30px]">
            {formatNumber(item.number)}
            {item?.data_type &&
            item?.data_type !== "number" &&
            item?.data_type !== "percentage" ? (
              <span className="text-sm"> {`(${item?.data_type})`} </span>
            ) : null}
          </p>
          {item?.percentage ? (
            <p className="text-[10px] font-light">{`${item.percentage}`}</p>
          ) : null}
        </div>
      ))}
    </div>
  );
}

export default IconsCards;
