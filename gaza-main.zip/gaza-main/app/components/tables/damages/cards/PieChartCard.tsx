"use client";

import dynamic from "next/dynamic";
import React from "react";
import getColors from "../helpers/getColors";
import formatNumber from "@/app/helpers/formatNumber";
const Chart = dynamic(() => import("react-apexcharts"), { ssr: false });

function PieChartCard({ data }: any) {
  return (
    <div>
      <Chart
        height={300}
        width="100%"
        options={{
          labels: data?.map(
            (item: any) =>
              `${item?.name} ( ${item?.data_type == "number" ? formatNumber(item?.number) : item?.data_type == "percentage" ? `${item?.number} %` : ""} )`,
          ),
          legend: {
            show: true,
            position: "bottom",
            fontFamily: "var(--font-primary)",
            fontSize: "10px",
            fontWeight: "300",
            horizontalAlign: "left",
            markers: {
              offsetX: 2,
              offsetY: 1,
              height: 8,
              width: 8,
            },
            itemMargin: {
              horizontal: 8,
              vertical: 0,
            },
          },
          dataLabels: {
            enabled: true,

            style: {
              fontFamily: "var(--font-primary)",
              fontSize: "10px",
              fontWeight: "300",
            },
          },
          colors: getColors(data?.length),
          tooltip: {
            enabled: true,

            y: {
              title: {
                formatter: (seriesName) => seriesName,
              },
              formatter: () => "",
            },
          },
          plotOptions: {
            pie: {
              dataLabels: {
                offset: -10,
              },
              startAngle: 0,
              endAngle: 360,
              expandOnClick: true,
              offsetX: 0,
              offsetY: 0,
              customScale: 1,
            },
          },
        }}
        series={data?.map((item: any) => +item?.number)}
        type="pie"
      />
    </div>
  );
}

export default PieChartCard;
