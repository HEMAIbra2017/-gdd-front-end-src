import formatNumber from "@/app/helpers/formatNumber";
import dynamic from "next/dynamic";
import React from "react";
const Chart = dynamic(() => import("react-apexcharts"), { ssr: false });

function DetailsDonuts({ data }: any) {
  return (
    <>
      {data?.map((item: any) => (
        <div className="text-xs min-w-fit" key={item.category}>
          <h2 className="text-base">{item?.category}</h2>
          <Chart
            height={115}
            options={{
              labels: item?.subcategories?.map((item: any) => item?.name),
              legend: { show: false },
              dataLabels: { enabled: false },
              colors: item?.colors,
              plotOptions: {
                pie: {
                  expandOnClick: false,
                  donut: {
                    size: "70%",
                    labels: { show: false },
                  },
                },
              },
            }}
            series={item?.subcategories?.map((item: any) => item?.number)}
            type="donut"
            width={78}
          />
          <div className={`  grid grid-cols-2 gap-2 w-fit  `}>
            {item?.subcategories?.map((sub: any, index: number) => (
              <div
                style={{ color: item?.colors?.[index] }}
                className="flex flex-col"
                key={sub.name}
              >
                <div className="flex flex-col items-center ">
                  <p className="font-light">{sub?.name}</p>
                  <p className="font-bold ">
                    {formatNumber(sub?.number)}
                  </p>
                  <p className="text-[10px] font-light ">
                    {sub?.percentage}
                  </p>
                </div>
              </div>
            ))}
          </div>
          {item?.last_updated_at ? (
            <div className="text-gray5 font-light">
              <p>تاريخ التحديث</p>
              <p className=" text-[10px]"> {item?.last_updated_at}</p>
            </div>
          ) : null}
        </div>
      ))}
    </>
  );
}

export default DetailsDonuts;
