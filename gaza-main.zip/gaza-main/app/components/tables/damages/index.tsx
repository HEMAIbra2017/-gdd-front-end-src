"use client";

import React, { useState } from "react";
import TablePageLayout from "../../ui/TablePageLayout";
import { Table } from "antd";
import { MobileColumns, columns } from "./tableData";
import DamageDetailsCard from "./DamageDetailsCard";
import PaginationComponent from "../../ui/PaginationComponent";
import { useTranslations } from "next-intl";
import ExpandIcon from "../ui/ExpandIcon";
import TableChildrenWrapper from "@/app/components/tables/ui/TableChildrenWrapper";

function DamagesTable({ data }: any) {
  const t = useTranslations();
  const dataSource = data?.results;
  return (
    <TablePageLayout className="" text={t("Damage Assessment")}>
      <>
        <Table
          pagination={false}
          className={`hidden sm:block`}
          expandable={{
            expandRowByClick: true,
            expandedRowRender: (record) => (
              <TableChildrenWrapper>
                <DamageDetailsCard data={record.cards} />{" "}
              </TableChildrenWrapper>
            ),
            expandIcon: ({
              expanded,
              record,
              onExpand,
            }: {
              expanded: boolean;
              record: any;
              onExpand: any;
            }) => (
              <ExpandIcon
                expanded={expanded}
                record={record}
                onExpand={onExpand}
              />
            ),
          }}
          dataSource={dataSource}
          columns={columns(t)}
        />
        <Table
          pagination={false}
          className="sm:hidden"
          expandable={{
            expandRowByClick: true,
            expandedRowRender: (record) => (
              <TableChildrenWrapper>
                <DamageDetailsCard data={record?.cards} />{" "}
              </TableChildrenWrapper>
            ),
            expandIcon: ({
              expanded,
              record,
              onExpand,
            }: {
              expanded: boolean;
              record: any;
              onExpand: any;
            }) => (
              <ExpandIcon
                expanded={expanded}
                record={record}
                onExpand={onExpand}
              />
            ),
          }}
          dataSource={dataSource}
          columns={MobileColumns(t)}
        />
        <PaginationComponent count={data?.count} />
      </>
      ;
    </TablePageLayout>
  );
}

export default DamagesTable;
