import React from "react";
import Image from "next/image";
import { useLocale } from "next-intl";

function GazaMap() {
  const locale = useLocale();
  return (
    <div className="flex items-center justify-center gap-x-9 bg-[#E6F5F1] py-[53px]">
      <div className="relative w-[200px] h-[200px] sm:w-[300px] sm:h-[300px]">
        <Image
          fill
          style={{
            objectFit: 'contain',
          }}
          src={`/gaza/gaza-${locale}.svg`}
          alt="gaza-in-palestine"
        />
      </div>
    </div>
  );
}

export default GazaMap;
