import React from "react";
import Download from "./Download";
import InfoContent from "./InfoContent";
import { twMerge } from "tailwind-merge";

const Reference = ({
  downloadPath,
  label,
  t,
}: {
  downloadPath: string;
  label: string;
  t: any;
}) => {
  return (
    <div>
      <h3 className="mb-3">{label}</h3>
      <Download t={t} downloadPath={downloadPath} />
    </div>
  );
};

function References({ t }:any) {
  return (
    <div>
      <h2 className={twMerge("title", "mb-6 mt-[111px] sm:mt-[85px]")}>
        مراجع عن قطاع غزة
      </h2>
      <div className="flex flex-wrap justify-center gap-6 sm:justify-between sm:gap-5">
        <Reference t={t} label="تقرير الحالة" downloadPath="/text.pdf" />
        <Reference t={t} label="تقرير الحالة" downloadPath="/text.pdf" />
        <Reference t={t} label="تقرير الحالة" downloadPath="/text.pdf" />
        <Reference t={t} label="تقرير الحالة" downloadPath="/text.pdf" />
      </div>
    </div>
  );
}

export default References;
