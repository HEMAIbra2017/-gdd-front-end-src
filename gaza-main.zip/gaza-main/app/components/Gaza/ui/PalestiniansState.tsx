import React from "react";
import InfoContent from "./InfoContent";
import Download from "./Download";
import useGetContent from "../helpers/useGetContent";
import VideoPlayer from "../../ui/VideoPlayer";

function PalestiniansState({ t }: any) {
  const {
    palestinians_video_url,
    palestinians_infographic,
    palestinians_report,
  } = useGetContent();

  return (
    <div>
      <InfoContent
        t={t}
        title={t("Palestinian Humanitarian Situation")}
        description={t("palestinian_situation_desc")}
      />
      <div className="flex flex-col gap-y-6 sm:flex-row sm:items-center sm:justify-between sm:gap-x-5 sm:gap-y-0">
        <Download
          t={t}
          label={t("Palestinian Humanitarian Situation Report")}
          downloadPath={palestinians_report}
        />
        <Download
          t={t}
          label={t("Video on the Palestinian Humanitarian Situation")}
          downloadPath={palestinians_infographic}
        />
      </div>

      {palestinians_video_url ? (
        <>
          {" "}
          <InfoContent
            t={t}
            title={`${t("Palestinian Humanitarian Situation")} 2022`}
          />
          <VideoPlayer videoUrl={palestinians_video_url} />
        </>
      ) : null}
    </div>
  );
}

export default PalestiniansState;
