import React from "react";
import InfoContent from "./InfoContent";
import Download from "./Download";
import useGetContent from "../helpers/useGetContent";
import VideoPlayer from "../../ui/VideoPlayer";

function GazaState({ t }: any) {
  const {
    gazza_video_url,
    panorama_video_url,
    gazza_infographic,
    gazza_report,
  } = useGetContent();

  return (
    <div>
      <InfoContent
        t={t}
        title={t("Gaza Strip Humanitarian Situation")}
        description={t("gaza_situation_desc")}
      />
      <div className="flex flex-col gap-y-6 sm:flex-row sm:items-center sm:justify-between sm:gap-x-5 sm:gap-y-0">
        <Download
          t={t}
          label={t("Gaza Strip Humanitarian Situation Report")}
          downloadPath={gazza_report}
        />
        <Download
          t={t}
          label={t("Video on the Palestinian Humanitarian Situation")}
          downloadPath={gazza_infographic}
        />
      </div>

      {gazza_video_url ? (
        <>
          <InfoContent
            t={t}
            title={`${t("Gaza Strip Humanitarian Situation")} 2022`}
          />
         <VideoPlayer videoUrl={gazza_video_url} />
        </>
      ) : null}

      {panorama_video_url ? (
        <>
          <InfoContent t={t} title={`${t("Gaza Panorama Film")} 2021`} />
          <VideoPlayer videoUrl={panorama_video_url} />
        </>
      ) : null}
    </div>
  );
}

export default GazaState;
