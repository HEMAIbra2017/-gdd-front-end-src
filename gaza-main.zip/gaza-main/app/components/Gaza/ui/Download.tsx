import React from "react";
import { twMerge } from "tailwind-merge";

function Download({
  downloadPath,
  label,
  t,
}: {
  downloadPath: string;
  label?: string;
  t: any;
}) {
  return (
    <div>
      {label ? <h3 className="label">{label}</h3> : null}
      <a
        className={twMerge("primary_btn", "block")}
        target="_blank"
        href={downloadPath}
      >
        {t("Download PDF File")}
      </a>
    </div>
  );
}

export default Download;
