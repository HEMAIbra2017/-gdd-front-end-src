import React, { useState } from "react";
import Download from "./Download";

function InfoContent({
  title,
  description,
  t,
}: {
  title: string;
  description?: string;
  t: any;
}) {
  const [show, setShow] = useState(false);
  return (
    <div>
      <h2 className="title">{title}</h2>
      {description ? (
        <div className="description mb-8">
          <span className={` ${show ? "" : "line-clamp-6 sm:line-clamp-3"} `}>
            {description}
          </span>
          <span
            className="cursor-pointer self-end text-primary underline"
            onClick={() => setShow((prev) => !prev)}
          >
            {show ? t("Less") : t("More")}
          </span>
        </div>
      ) : null}
    </div>
  );
}

export default InfoContent;
