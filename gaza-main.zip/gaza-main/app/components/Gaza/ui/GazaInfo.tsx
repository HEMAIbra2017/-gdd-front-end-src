import React from "react";
import InfoContent from "./InfoContent";

function GazaInfo({ t }: any) {
  return (
    <InfoContent
      t={t}
      title={t("About Gaza Strip")}
      description={t("gaza_strip_desc")}
    />
  );
}

export default GazaInfo;
