import { useLocale } from "next-intl";

export default function useGetContent() {
  const locale = useLocale();
  
  const videoBaseUrl = "https://www.dailymotion.com/embed/video/";
  const pdfBaseUrl = "https://drive.google.com/file/d/";
  const gazza_state_ids: any = {
    ar: {
      video: "x8tysfy",
      pdf: {
        infographic: "1f1skHcII963SNsOECnuz7lCnyzMFT5tp",
        report: "1NdSyA_w_YvrAi1IWBHwzVWuvXaJyR9IN",
      },
    },
    en: {
      video: "x8tyse0",
      pdf: {
        infographic: "1pNQnVaH0UVSsyu2TIFZLAo546ke-JiTJ",
        report: "1gSpfW3IGcR8iGCZ451lCqZlJOrwprqQs",
      },
    },
    ID: {
      video: "k35k38FNxyCOzaAeABk",
      pdf: {
        infographic: "1173NhGvUBifJLcQoUcHM5NEmuGs_omzP",
        report: "1kgSq35jdkxDv-P7QHLoUpWoWkwQiSNNm",
      },
    },
    tr: {
      video: "x8tysdy",
      pdf: {
        infographic: "1uYDL5L0DEtS_fwuf-AwDMxe5xGzWHvGw",
        report: "1JjBtMYWyu--1aSewwDCemp2lSAujQ7hr",
      },
    },
  };

  const gazza_panorama_ids: any = {
    ar: "x8tytc4",
    en: "x8tytc2",
    ID: "k25LoPY7fudkB5AeABm",
    tr: "x8tytc6",
  };

  const palestinians_state_ids: any = {
    ar: {
      video: "x8tytds",
      pdf: {
        infographic: "1I3e9ABP77jiYQa--XFInYmhP9oWkJsjF",
        report: "1UaKc9uszVoCOjP77Vxki4mFm4TS53zxr",
      },
    },
    en: {
      video: "x8tytdw",
      pdf: {
        infographic: "1rpgGRY3cWn9vo4k_fvCwD1zJYT6zDsuX",
        report: "12zE2WwoMvRIYsFeQCwPVENrz4q2S2im9",
      },
    },
    ID: {
      video: "k2986hKEUgpVJ2AeABq",
      pdf: {
        infographic: "1t93GxNjTdyITyyiMx4SNsYoCG1ilrOqj",
        report: "1AaiQi0cb6woQJgPcEnUCOGLlQpYivOjN",
      },
    },
    tr: {
      video: "x8tytdu",
      pdf: {
        infographic: "12uZwnduYASYlJAiRmtWCwWSKieS1Cho2",
        report: "1WyYtkawCTvlbbtVwOEpnN7ElDOaI7Pw0",
      },
    },
  };
  const gazza_video_url = `${videoBaseUrl}${gazza_state_ids[locale]["video"]}`;
  const panorama_video_url = `${videoBaseUrl}${gazza_panorama_ids[locale]}`;
  const palestinians_video_url = `${videoBaseUrl}${palestinians_state_ids[locale]["video"]}`;
  const gazza_infographic = `${pdfBaseUrl}${gazza_state_ids[locale]["pdf"]["infographic"]}/view`;
  const gazza_report = `${pdfBaseUrl}${gazza_state_ids[locale]["pdf"]["report"]}/view`;
  const palestinians_infographic = `${pdfBaseUrl}${palestinians_state_ids[locale]["pdf"]["infographic"]}/view`;
  const palestinians_report = `${pdfBaseUrl}${palestinians_state_ids[locale]["pdf"]["report"]}/view`;

  return {
    gazza_video_url,
    panorama_video_url,
    palestinians_video_url,
    gazza_infographic,
    gazza_report,
    palestinians_infographic,
    palestinians_report,
  };
}
