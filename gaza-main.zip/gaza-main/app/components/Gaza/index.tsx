"use client";

import React from "react";
import GazaInfo from "./ui/GazaInfo";
import GazaMap from "./ui/GazaMap";
import PalestiniansState from "./ui/PalestiniansState";
import GazaState from "./ui/GazaState";
import References from "./ui/References";
import { twMerge } from "tailwind-merge";
import { useTranslations } from "next-intl";

function Gaza() {
  const t = useTranslations();
  return (
    <div>
      <div
        className={twMerge(
          "container",
          " mx-auto max-w-[906px] pt-0 sm:pt-[5px]",
        )}
      >
        <GazaInfo t={t} />
      </div>
      <GazaMap />
      <div className={twMerge("container", " mx-auto max-w-[906px] pt-0")}>
        <PalestiniansState t={t} />
        <GazaState t={t} />
        {/* <References t={t} /> */}
      </div>
    </div>
  );
}

export default Gaza;
