import PlanetIcon from "@/public/hero/planet.svg";
import ChildIcon from "@/public/hero/child.svg";
import WomanIcon from "@/public/hero/woman.svg";
import TombIcon from "@/public/hero/tomb.svg";
import InjuredIcon from "@/public/hero/injured.svg";
import HouseIcon from "@/public/hero/house.svg";
import FactoryIcon from "@/public/hero/factory.svg";

export default function heroIcons(index: number) {
  const mapping: any = {
    0: TombIcon,
    1: InjuredIcon,
    2: HouseIcon,
    3: FactoryIcon,
    4: PlanetIcon,
  };

  return mapping[index];
}
export function heroDetailsIcons(index: number) {
  const mapping: any = {
    0: ChildIcon,
    1: WomanIcon,
  };
  return mapping[index];
}
