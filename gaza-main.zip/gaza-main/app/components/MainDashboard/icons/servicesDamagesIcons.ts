import BordersIcon from "@/public/services-damages/1.svg";
import RoadsIcon from "@/public/services-damages/2.svg";
import WatersNetIcon from "@/public/services-damages/3.svg";
import WatersNet2Icon from "@/public/services-damages/4.svg";
import AbarIcon from "@/public/services-damages/5.svg";

export { BordersIcon, RoadsIcon, WatersNetIcon, WatersNet2Icon, AbarIcon };
