import WatersNetIcon from "@/public/services-damages/3.svg";
import WatersNet2Icon from "@/public/services-damages/4.svg";
import SchoolIcon from "@/public/icons/schools.svg";
import DefenseCarIcon from "@/public/icons/defense-car.svg";
import TrashCarIcon from "@/public/icons/trashCar.svg";
import ReliefIcon from "@/public/icons/relief.svg";
import PlanIcon from "@/public/icons/plan.svg";
import CarIcon from "@/public/icons/car.svg";

export {
  WatersNetIcon,
  WatersNet2Icon,
  SchoolIcon,
  DefenseCarIcon,
  TrashCarIcon,
  ReliefIcon,
  PlanIcon,
  CarIcon,
};
