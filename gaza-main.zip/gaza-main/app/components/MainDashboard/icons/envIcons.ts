import BombIcon from "@/public/env-icons/1.svg";
import FanIcon from "@/public/env-icons/2.svg";
import StoneIcon from "@/public/env-icons/3.svg";
import MedicalBottleIcon from "@/public/env-icons/4.svg";
import TrashIcon from "@/public/env-icons/5.svg";

export { BombIcon, FanIcon, StoneIcon, MedicalBottleIcon, TrashIcon };
