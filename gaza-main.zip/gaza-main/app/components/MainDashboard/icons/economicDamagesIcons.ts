import CommertialBuildingIcon from "@/public/economic-damages/1.svg";
import PlanetIcon from "@/public/economic-damages/2.svg";
import FactoryIcon from "@/public/economic-damages/3.svg";
import BankIcon from "@/public/economic-damages/4.svg";
import TourismIcon from "@/public/economic-damages/5.svg";
import BoatIcon from "@/public/economic-damages/6.svg";
import MarketIcon from "@/public/economic-damages/7.svg";
import JobLostIcon from "@/public/icons/jobLost.svg";

export {
  CommertialBuildingIcon,
  PlanetIcon,
  FactoryIcon,
  BankIcon,
  TourismIcon,
  BoatIcon,
  MarketIcon,
  JobLostIcon,
};
