import BuildingsIcon from "@/public/health-icons/1.svg";
import HospitalsIcon from "@/public/health-icons/2.svg";
import AmbulanceIcon from "@/public/health-icons/3.svg";


export {BuildingsIcon,HospitalsIcon, AmbulanceIcon }