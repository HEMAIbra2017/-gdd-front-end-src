"use client";

import React from "react";
import { DevelopmentComponent, RecoveryComponent, ReliefComponent } from "./SecondaryComponents";

function SecondaryProgress({
  from,
  Total_Summary,
}: {
  from?: string;
  Total_Summary: {
    relief: number;
    recovery: number;
    development: number;
  };
}) {
  return (
    <div
      className={` ${from == "card" ? "flex-col" : "overflow-auto scrollbar-hide"}  flex w-full justify-start gap-x-5 gap-y-4   lg:flex-row  lg:items-center lg:gap-y-0 xl:justify-between`}
    >
      <ReliefComponent from={from} secondaryData={Total_Summary} />
      <RecoveryComponent from={from} secondaryData={Total_Summary} />
      <DevelopmentComponent from={from} secondaryData={Total_Summary} />
    </div>
  );
}

export default SecondaryProgress;
