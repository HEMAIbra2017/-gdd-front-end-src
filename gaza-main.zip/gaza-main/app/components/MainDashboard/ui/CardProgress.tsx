"use client";

import React from "react";
import ProgressLine from "./Progress";
import Image from "next/image";
import formatNumber from "@/app/helpers/formatNumber";
const CardProgress = ({
  data: { percent, img, title, number },
}: {
  data: {
    title: string;
    img?: string;
    textColor: string;
    percent: number;
    number: number;
  };
}) => {
  return (
    <div className={` flex w-full flex-col  text-darkGreen`}>
      <div className="mb-[-6px] flex items-center justify-between gap-x-[10px] text-sm">
        <div className="flex items-center gap-x-1">
          {img ? (
            <Image className="h-auto w-auto" src={img} alt={title} />
          ) : null}
          <h3 className=" text-xs">{title}</h3>
        </div>
        <p className="text-xs font-light">{formatNumber(number)}</p>
      </div>
      <ProgressLine percent={percent} />
      <span className="  mt-[-12px] self-end text-[10px] font-light ">
        {percent}
      </span>
    </div>
  );
};

export default CardProgress;
