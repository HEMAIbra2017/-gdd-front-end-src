"use client";

import React from "react";
import ProgressLine from "./Progress";
import { useTranslations } from "next-intl";
import formatNumber from "@/app/helpers/formatNumber";

function MainProgress({ total }: { total: number }) {
  const t = useTranslations();

  const current = 0;
  return (
    <div className="flex  w-full max-w-[400px] flex-col  rounded-2xl border-[0.5px] border-primary bg-lightGreen p-4">
      <h3 className=" mb-2  text-sm font-semibold text-darkGreen sm:text-xl">
        {t("Total Amount")}
      </h3>
      <ProgressLine
        color="var(--green1-color)"
        percent={(current / total) * 100}
      />
      <div className="mt-[-12px] flex items-center justify-between gap-x-5 text-darkGreen sm:gap-x-20">
        <span className=" text-sm font-semibold sm:text-base opacity-0">
          {current}
          <span>%</span>
        </span>
        <span className="text-xs font-semibold  sm:text-sm ">
          <span>$</span>
          {formatNumber(total)}
        </span>
      </div>
    </div>
  );
}

export default MainProgress;
