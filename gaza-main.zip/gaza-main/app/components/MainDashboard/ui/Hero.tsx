import Image from "next/image";
import React from "react";
import heroIcons, { heroDetailsIcons } from "../icons/heroIcons";
import { useTranslations } from "next-intl";

type CardDeetailsProps = { number: number | string; name: string }[];

type CardProps = {
  number: number | string;
  name: string;
  details?: CardDeetailsProps;
  index: number;
};

const HeroCard = ({ number, name, details, index }: CardProps) => {
  return (
    <div className="flex h-full    justify-center gap-x-6  rounded-3xl border  border-white bg-black bg-opacity-[33%] p-4 text-white sm:px-6 lg:min-h-[180px]    lg:border-none">
      <div className="flex   items-center gap-x-3 gap-y-4 lg:flex-col lg:justify-center lg:gap-x-0">
        <Image
          src={heroIcons(index)}
          alt="hero card icon"
          className="h-[36px] w-auto "
        />
        <div className="flex  flex-col  items-center gap-x-3 lg:gap-y-1 ">
          <p className="text-2xl font-bold lg:text-[28px]">{number}</p>
          <p className="text max-w-[200px] text-center text-[10px] font-light lg:text-base lg:font-semibold">
            {name}
          </p>
        </div>
      </div>
      {details ? (
        <div className="hidden h-full flex-col gap-y-1 lg:flex ">
          {details?.map((item, index) => (
            <div
              key={index}
              className="flex h-full  items-center  justify-between gap-x-6 rounded-2xl bg-black bg-opacity-30 px-4 py-3"
            >
              <Image
                src={heroDetailsIcons(index)}
                alt="planet icon"
                className="h-[28px] w-auto "
              />
              <div className="flex flex-col items-center">
                <p className="text-xl">{item?.number}</p>
                <p className="text-xs font-semibold">{item?.name}</p>
              </div>
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
};

function Hero({ data }: { data: CardProps[] }) {
  const t = useTranslations();

  const details = data?.splice(1, 2);
  return (
    <div className=" relative bg-gray-900 ">
      <div className=" h-full w-full bg-opacity-50 bg-hero_mobile   bg-center py-5    lg:bg-hero">
        {" "}
        <div className="relative z-10 h-full w-full  px-4 ">
          {/* <p className="text-2xl text-white mb-8 hidden lg:block">في كل ساعة</p> */}
          <div className=" grid grid-cols-2 items-center gap-x-3 gap-y-6 sm:grid-cols-3 lg:flex lg:flex-wrap lg:justify-center">
            <p className="max-w-[200px] text-2xl leading-[42px] tracking-widest   text-white sm:text-4xl	sm:leading-[54px] sm:tracking-normal">
              {t("Damage per Hour")}
            </p>

            {data?.map((item: CardProps, index: number) => (
              <HeroCard
                key={index}
                number={item?.number}
                name={item?.name}
                index={index}
                details={index == 0 ? details : undefined}
              />
            ))}
          </div>
        </div>
      </div>
      <div className="absolute inset-0 h-full w-full bg-gradient-to-l from-[#4C0505] via-[#1D0505] to-transparent"></div>
    </div>
  );
}

export default Hero;
