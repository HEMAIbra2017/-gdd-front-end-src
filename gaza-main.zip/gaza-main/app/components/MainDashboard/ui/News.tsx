"use client";

import Image from "next/image";
import React, { useEffect, useState } from "react";

function News({ news }: { news: string }) {
  const [hideNews, setHideNews] = useState<any>("1");
  const handleCloseNews = () => {
    setHideNews("1");
    sessionStorage.setItem("hide_news", "1");
  };

  useEffect(() => {
    if (typeof window !== "undefined") {
      setHideNews(sessionStorage?.getItem("hide_news"));
    }
  }, []);

  return (
    <div
      className={` ${
        hideNews == "1" ? "hidden" : ""
      }  relative flex items-center justify-center bg-red3  py-4  pl-10 pr-4 text-xs font-light text-white  sm:px-6 sm:text-sm sm:font-normal`}
    >
      <div>{news}</div>
      <Image
        onClick={handleCloseNews}
        className="absolute left-2 top-1/2 -translate-y-1/2 cursor-pointer sm:left-6"
        src="/icons/xIcon.svg"
        height={24}
        width={24}
        alt="x-icon"
      />
    </div>
  );
}

export default News;
