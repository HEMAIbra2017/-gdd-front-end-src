import Image from "next/image";
import ProgressLine from "./Progress";
import Icon1 from "@/public/icons/1.svg";
import Icon2 from "@/public/icons/2.svg";
import Icon3 from "@/public/icons/3.svg";
import getNumber from "@/app/helpers/getNumber";
import { useLocale, useTranslations } from "next-intl";
import formatNumber from "@/app/helpers/formatNumber";
function SecondaryComponent({
  percent,
  img,
  color,
  title,
  from,
  className,
}: {
  title: {
    text: string;
    color: string;
  };
  img: string;
  color: string;
  from?: string;
  className?: string;
  percent: { current: number; total: number; trailColor?: string };
}) {
  const locale = useLocale();
  return (
    <div
      dir={locale == "ar" ? "rtl" : "ltr"}
      className={`flex flex-col ${className ?? ""} ${
        from == "card" ? " sm:w-[216px]" : " w-full  min-w-[247px]"
      }`}
    >
      <div className="flex items-center  gap-x-[10px] ">
        <Image
          className={`h-auto  ${from == "card" ? " w-4 sm:w-auto" : "w-auto"} `}
          src={img}
          alt={title?.text}
        />
        <h3
          className={` text-xs sm:text-sm ${from == "card" ? "font-normal" : "font-bold"} ${
            title?.color
          }`}
        >
          {title?.text}
        </h3>
      </div>
      <div>
        <ProgressLine
          trailColor={from == "card" ? "#E6F5F1" : percent?.trailColor}
          color={color}
          percent={percent?.current}
        />
      </div>

      <div
        className={`mt-[-10px] flex items-center   justify-between text-black3`}
      >
        <span className="text-sm font-semibold opacity-0">
          {percent?.current}
          <span>%</span>
        </span>
        <span className=" text-xs ">
          <span>$</span>
          {formatNumber(percent?.total)}
        </span>
      </div>
    </div>
  );
}

export function ReliefComponent({ from, secondaryData }: any) {
  const t = useTranslations();

  if (!secondaryData) return;
  return (
    <SecondaryComponent
      from={from}
      title={{
        text: t("Relief"),
        color: "text-borderRed",
      }}
      className={
        from == "card"
          ? ""
          : "rounded-2xl border-[0.5px] border-borderRed bg-lightRed p-4"
      }
      color="var(--border-red)"
      img={Icon1}
      percent={{
        current: 0,
        total: secondaryData?.relief,
        trailColor: "#F1BEBE",
      }}
    />
  );
}
export function RecoveryComponent({ from, secondaryData }: any) {
  const t = useTranslations();

  if (!secondaryData) return;

  return (
    <SecondaryComponent
      from={from}
      className={
        from == "card"
          ? ""
          : "rounded-2xl border-[0.5px] border-borderBlue bg-lightBlue p-4"
      }
      title={{
        text: t("Recovery"),
        color: "text-blue1",
      }}
      color="var(--blue1-color)"
      img={Icon2}
      percent={{
        current: 0,
        total: secondaryData?.recovery,
        trailColor: "#B7C0F0",
      }}
    />
  );
}
export function DevelopmentComponent({ from, secondaryData }: any) {
  const t = useTranslations();

  if (!secondaryData) return;

  return (
    <SecondaryComponent
      from={from}
      className={
        from == "card"
          ? ""
          : "rounded-2xl border-[0.5px] border-borderGreen bg-lightGreen p-4"
      }
      title={{
        text: t("Development"),
        color: "text-green2",
      }}
      color="var(--green2-color)"
      img={Icon3}
      percent={{
        current: 0,
        total: secondaryData?.development,
        trailColor: "#BDEBC9",
      }}
    />
  );
}
