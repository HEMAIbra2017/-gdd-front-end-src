import { Progress } from "antd";
import React from "react";

export default function ProgressLine({
  percent,
  color,
  trailColor,
}: {
  percent: number;
  color?: string;
  trailColor?: string;
}) {
  return (
    <Progress
      trailColor={trailColor || "#B0DFD3"}
      strokeColor={color || "#00543E"}
      size="small"
      percent={percent}
      showInfo={false}
    />
  );
}
