import Image from "next/image";
import React from "react";
import arrowIcon from "@/public/icons/arrow.svg";
import SecondaryProgress from "./SecondaryProgress";
import { useRouter } from "@/navigation";
import { useLocale } from "next-intl";

function MainCard({
  title,
  route,
  children,
  secondaryData,
}: {
  title: string;
  route?: string;
  secondaryData: {
    relief: number;
    recovery: number;
    development: number;
  };
  children: React.ReactNode;
}) {
  const { push } = useRouter();
  const locale = useLocale();
  return (
    <div className="  main-card flex break-inside-avoid   flex-col gap-y-5 bg-lightGreen duration-200 hover:bg-hoverGreen">
      <div
        className={`section-title group flex items-center gap-x-2 ${route ? "cursor-pointer" : ""}`}
        onClick={() => {
          if (route) {
            push("/damages");
          }
        }}
      >
        <h2 className="text-sm font-semibold text-darkGreen duration-150 hover:text-primary sm:text-xl">
          {title}
        </h2>
        {route ? (
          <div className={`h-4 w-3 bg-arrow bg-no-repeat duration-150 group-hover:bg-arrow_hover ${locale == "ar" ? "" : "rotate-180"} `} />
        ) : null}
      </div>
      <div>{children}</div>
      <div className="data-card bg-white">
        <SecondaryProgress Total_Summary={secondaryData} from="card" />
      </div>
    </div>
  );
}
export default MainCard;
