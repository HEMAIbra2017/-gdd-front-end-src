"use client";

import React from "react";
import { Carousel } from "antd";
import {
  DevelopmentComponent,
  RecoveryComponent,
  ReliefComponent,
} from "./SecondaryComponents";

function MobileSecondaryProgress({
  from,
  Total_Summary,
}: {
  from?: string;
  Total_Summary: {
    relief: number;
    recovery: number;
    development: number;
  };
}) {
  return (
    <div className="md:hidden">
      <Carousel autoplaySpeed={5000} dots={false} autoplay>
        <ReliefComponent from={from} secondaryData={Total_Summary} />
        <RecoveryComponent from={from} secondaryData={Total_Summary} />
        <DevelopmentComponent from={from} secondaryData={Total_Summary} />
      </Carousel>
    </div>
  );
}

export default MobileSecondaryProgress;
