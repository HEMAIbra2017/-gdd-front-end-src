import React from "react";
import MainCard from "../MainCard";
import CardTwo from "./DataCards/CardTwo";
import {
  BankIcon,
  BoatIcon,
  CommertialBuildingIcon,
  FactoryIcon,
  MarketIcon,
  PlanetIcon,
  TourismIcon,
  JobLostIcon
} from "../../icons/economicDamagesIcons";
import { SectorDataTypes } from "../../DashBody";

function EconomicDamageCard({
  data,
  damage_percentage,
}: {
  data: SectorDataTypes;
  damage_percentage: string;
}) {
  const details = data?.details;


  return (
    <MainCard
      secondaryData={{
        relief: data?.relief,
        recovery: data?.recovery,
        development: data?.development,
      }}
      title={data?.name}
      route="/damages"
    >
      <div className="">
        <CardTwo
          viewClass="grid grid-cols-2 lg:grid-cols-3 gap-x-10   gap-y-4"
          data={[
            {
              icon: CommertialBuildingIcon,
              text: details?.[0]?.name,
              subtext: `${details?.[0]?.damage_percentage} ${damage_percentage}`,
              number: details?.[0]?.number,
            },
            {
              icon: PlanetIcon,
              text: details?.[4]?.name,
              subtext: `${details?.[4]?.damage_percentage} ${damage_percentage}`,
              number: details?.[4]?.number,
            },
            {
              icon: FactoryIcon,
              text: details?.[5]?.name,
              subtext: `${details?.[5]?.damage_percentage} ${damage_percentage}`,
              number: details?.[5]?.number,
            },
            {
              icon: BankIcon,
              text: details?.[3]?.name,
              subtext: `${details?.[3]?.damage_percentage} ${damage_percentage}`,
              number: details?.[3]?.number,
            },
            {
              icon: TourismIcon,
              text: details?.[2]?.name,
              subtext: `${details?.[2]?.damage_percentage} ${damage_percentage}`,
              number: details?.[2]?.number,
            },
            {
              icon: BoatIcon,
              text: details?.[7]?.name,
              subtext: `${details?.[7]?.damage_percentage} ${damage_percentage}`,
              number: details?.[7]?.number,
            },
            {
              icon: MarketIcon,
              text: details?.[1]?.name,
              subtext: `${details?.[1]?.damage_percentage} ${damage_percentage}`,
              number: details?.[1]?.number,
            },
            {
              icon: BoatIcon,
              text: details?.[6]?.name,
              subtext: `${details?.[6]?.damage_percentage} ${damage_percentage}`,
              number: details?.[6]?.number,
            },
            {
              icon: JobLostIcon,
              text: details?.[8]?.name,
              subtext: `${details?.[8]?.damage_percentage} ${damage_percentage}`,
              number: details?.[8]?.number,
            },
          ]}
        />
      </div>
    </MainCard>
  );
}

export default EconomicDamageCard;
