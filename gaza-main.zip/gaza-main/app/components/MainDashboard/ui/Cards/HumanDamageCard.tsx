import React from "react";
import MainCard from "../MainCard";
import CardOne from "./DataCards/CardOne";
import {
  babyIcon,
  shohadaaIcon,
  mosabeenIcon,
  femaleIcon,
  maleIcon,
  questionMarkIcon,
  homeless,
} from "@/app/components/icons";
import { SectorDataTypes } from "../../DashBody";

function HumanDamageCard({
  data,
  percentage_text,
}: {
  data: SectorDataTypes;
  percentage_text: string;
}) {
  const details = data?.details;
  return (
    <MainCard
      secondaryData={{
        relief: data?.relief,
        recovery: data?.recovery,
        development: data?.development,
      }}
      title={data?.name}
      route="/damages"
    >
      <div className="flex grid-cols-2  flex-col gap-2 lg:grid">
        <CardOne
          detailsData={[
            {
              class: "sm:w-[98px]",
              img: maleIcon,
              title: details?.[4]?.name,
              number: details?.[4]?.number,
            },
            {
              class: "sm:w-[98px]",
              img: femaleIcon,
              title: details?.[3]?.name,
              number: details?.[3]?.number,
            },
            {
              class: "sm:w-[98px]",
              img: babyIcon,
              title: details?.[2]?.name,
              number: details?.[2]?.number,
            },
          ]}
          data={{
            icon: shohadaaIcon,
            text: details?.[1]?.name,
            subtext: `${details?.[1]?.damage_percentage} ${percentage_text}`,
            number: details?.[1]?.number,
          }}
        />
        <CardOne
          detailsData={[
            {
              title: details?.[10]?.name,
              number: details?.[10]?.number,
            },
            {
              title: details?.[9]?.name,
              number: details?.[9]?.number,
            },
            {
              title: details?.[7]?.name,
              number: details?.[7]?.number,
            },
            {
              title: details?.[8]?.name,
              number: details?.[8]?.number,
            },
          ]}
          data={{
            icon: mosabeenIcon,
            text: details?.[6]?.name,
            subtext: `${details?.[6]?.damage_percentage} ${percentage_text}`,
            number: details?.[6]?.number,
          }}
        />
        <CardOne
          data={{
            icon: homeless,
            text: details?.[11]?.name,
            subtext: `${details?.[11]?.damage_percentage} ${percentage_text}`,
            number: details?.[11]?.number,
          }}
        />
        <CardOne
          data={{
            icon: questionMarkIcon,
            text: details?.[5]?.name,
            subtext: `${details?.[5]?.damage_percentage} ${percentage_text}`,
            number: details?.[5]?.number,
          }}
        />
      </div>
    </MainCard>
  );
}

export default HumanDamageCard;
