import React from "react";
import MainCard from "../MainCard";
import CardTwo from "./DataCards/CardTwo";
import {
  AbarIcon,
  BordersIcon,
  RoadsIcon,
  WatersNet2Icon,
  WatersNetIcon,
} from "../../icons/servicesDamagesIcons";
import { SectorDataTypes } from "../../DashBody";

function ServicesDamageCard({ data, damage_percentage }: { data: SectorDataTypes; damage_percentage:string }) {
  const details = data?.details;

  return (
    <MainCard
      secondaryData={{
        relief: data?.relief,
        recovery: data?.recovery,
        development: data?.development,
      }}
      title={data?.name}
      route="/damages"
    >
      <div className="">
        <CardTwo
          viewClass="flex items-start flex-wrap  gap-x-8"
          data={[
            {
              icon: BordersIcon,
              text: details?.[0]?.name,
              subtext: `${details?.[0]?.damage_percentage} ${damage_percentage}`,
              number: details?.[0]?.number,
            },

            {
              icon: RoadsIcon,
              text: details?.[1]?.name,
              number: details?.[1]?.number,
            },

            {
              icon: WatersNetIcon,
              text: details?.[2]?.name,
              number: details?.[2]?.number,
            },

            {
              icon: WatersNet2Icon,
              text: details?.[3]?.name,
              number: details?.[3]?.number,
            },

            {
              icon: AbarIcon,
              text: details?.[4]?.name,
              number: details?.[4]?.number,
              subtext: `${details?.[4]?.damage_percentage} ${damage_percentage}`,
            },
          ]}
        />
      </div>
    </MainCard>
  );
}

export default ServicesDamageCard;
