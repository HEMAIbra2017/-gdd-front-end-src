import React from "react";
import MainCard from "../MainCard";
import CardTwo from "./DataCards/CardTwo";
import {
  SchoolIcon,
  WatersNetIcon,
  WatersNet2Icon,
  DefenseCarIcon,
  TrashCarIcon,
  ReliefIcon,
  CarIcon,
  PlanIcon
} from "../../icons/governaceIcons";
import { SectorDataTypes } from "../../DashBody";

function GovernaceDamageCard({
  data,
  damage_percentage,
}: {
  data: SectorDataTypes;
  damage_percentage: string;
}) {
  const details = data?.details;
  return (
    <MainCard
      secondaryData={{
        relief: data?.relief,
        recovery: data?.recovery,
        development: data?.development,
      }}
      title={data?.name}
      route="/damages"
    >
      <div className="">
        <CardTwo
          viewClass="grid grid-cols-2 lg:grid-cols-3 gap-x-10   gap-y-4"
          data={[
            {
              icon: SchoolIcon,
              text: details?.[1]?.name,
              subtext: `${details?.[1]?.damage_percentage} ${damage_percentage}`,
              number: details?.[1]?.number,
            },
            {
              icon: DefenseCarIcon,
              text: details?.[2]?.name,
              subtext: `${details?.[2]?.damage_percentage} ${damage_percentage}`,
              number: details?.[2]?.number,
            },
            {
              icon: WatersNetIcon,
              text: details?.[4]?.name,
              subtext: `${details?.[4]?.damage_percentage} ${damage_percentage}`,
              number: details?.[4]?.number,
            },
            {
              icon: TrashCarIcon,
              text: details?.[6]?.name,
              subtext: `${details?.[6]?.damage_percentage} ${damage_percentage}`,
              number: details?.[6]?.number,
            },
            {
              icon: WatersNet2Icon,
              text: details?.[5]?.name,
              subtext: `${details?.[5]?.damage_percentage} ${damage_percentage}`,
              number: details?.[5]?.number,
            },
            {
              icon: ReliefIcon,
              text: details?.[7]?.name,
              subtext: `${details?.[7]?.damage_percentage} ${damage_percentage}`,
              number: details?.[7]?.number,
            },
            {
              icon: CarIcon,
              text: details?.[3]?.name,
              subtext: `${details?.[3]?.damage_percentage} ${damage_percentage}`,
              number: details?.[3]?.number,
            },
            {
              icon: PlanIcon,
              text: details?.[0]?.name,
              subtext: `${details?.[0]?.damage_percentage} ${damage_percentage}`,
              number: details?.[0]?.number,
            },
          ]}
        />
      </div>
    </MainCard>
  );
}

export default GovernaceDamageCard;
