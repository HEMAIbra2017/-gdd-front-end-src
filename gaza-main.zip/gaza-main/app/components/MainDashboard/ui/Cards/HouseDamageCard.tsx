import React from "react";
import MainCard from "../MainCard";
import CardOne from "./DataCards/CardOne";
import { RedhomeIcon } from "@/app/components/icons";
import { SectorDataTypes } from "../../DashBody";

function HouseDamageCard({
  data,
  damage_percentage,
}: {
  data: SectorDataTypes;
  damage_percentage: string;
}) {
  const details = data?.details;

  return (
    <MainCard
      secondaryData={{
        relief: data?.relief,
        recovery: data?.recovery,
        development: data?.development,
      }}
      title={data?.name}
      route="/damages"
    >
      <div className="">
        <CardOne
          detailsGridCols="flex flex-col sm:grid sm:grid-cols-2 gap-x-4"
          detailsData={[
            {
              title: details?.[1]?.name,
              number: details?.[1]?.number,
              percent: details?.[1]?.damage_percentage,
            },
            {
              title: details?.[2]?.name,
              number: details?.[2]?.number,
              percent: details?.[2]?.damage_percentage,
            },
            {
              title: details?.[3]?.name,
              number: details?.[3]?.number,
              percent: details?.[3]?.damage_percentage,
            },
          ]}
          data={{
            icon: RedhomeIcon,
            text: details?.[0]?.name,
            subtext: `${details?.[0]?.damage_percentage} ${damage_percentage}`,
            number: details?.[0]?.number,
          }}
        />
      </div>
    </MainCard>
  );
}

export default HouseDamageCard;
