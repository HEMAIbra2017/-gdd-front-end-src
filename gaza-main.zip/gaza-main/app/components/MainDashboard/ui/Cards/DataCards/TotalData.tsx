import formatNumber from "@/app/helpers/formatNumber";
import Image from "next/image";

const TotalData = ({
  data: { icon, text, number, subtext },
}: {
  data: {
    icon?: string;
    text: string;
    number: number;
    subtext?: string;
  };
}) => {
  return (
    <div className="flex flex-col">
      {icon ? (
        <Image
          src={icon}
          alt={text}
          className="mb-2 h-7 w-fit object-contain sm:h-[35px]"
        />
      ) : null}
      <p className="text-xs font-semibold  text-primary sm:text-base">{text}</p>
      <p className="font-semibold text-darkGreen sm:text-xl">
        {formatNumber(number)}{" "}
      </p>
      {subtext ? (
        <p className="text-[8px] font-light text-gray6">{subtext}</p>
      ) : null}
    </div>
  );
};

export default TotalData;
