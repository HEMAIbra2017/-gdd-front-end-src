import React from "react";
import TotalData from "./TotalData";

function CardTwo({ data, viewClass }: { data: any; viewClass: string }) {
  return (
    <div className={`${viewClass}  gap-y-4 data-card bg-white `}>
      {data?.map((item: any, index: number) => (
        <TotalData key={index} data={item} />
      ))}
    </div>
  );
}

export default CardTwo;
