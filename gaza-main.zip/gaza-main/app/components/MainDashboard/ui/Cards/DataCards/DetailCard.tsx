import formatNumber from "@/app/helpers/formatNumber";
import Image from "next/image";
import React from "react";

function DetailCard({
  title,
  img,
  number,
}: {
  title: string;
  img?: string;
  number: number;
}) {
  return (
    <div className={`flex flex-col ${img? "items-center" :""} text-darkGreen `}>
      {img ? <Image width={13.33} src={img} className="h-auto" alt={title} /> : null}
      <p className="text-xs">{title}</p>
      <p className="text-sm font-semibold">{formatNumber(number)}</p>
    </div>
  );
}

export default DetailCard;
