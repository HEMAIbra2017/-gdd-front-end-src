import React from "react";
import CardProgress from "../../CardProgress";
import ProgressLine from "../../Progress";
import TotalData from "./TotalData";
import DetailCard from "./DetailCard";

function CardOne({ data, detailsData, detailsGridCols, totalDetails }: any) {
  const isFirstCard = detailsData?.[0]?.percent;
  return (
    <div
      className={`bg-white  data-card flex flex-col gap-y-4 sm:gap-y-0 sm:flex-row gap-x-4   justify-between `}
    >
      <TotalData data={data} />
      {isFirstCard ? (
        <div
          className={`   ${
            detailsGridCols ? `${detailsGridCols}` : "flex flex-col"
          } gap-y-4`}
        >
          {detailsData
            ? detailsData?.map((item: any, index: number) => (
                <div
                  key={index}
                  className={`${item?.class ? item?.class : "sm:w-[130px]"} `}
                >
                  <CardProgress
                    data={{
                      textColor: item?.textColor,
                      img: item?.img,
                      title: item?.title,
                      percent: Number(item?.percent.replace("%", "")),
                      number: item?.number,
                    }}
                  />
                </div>
              ))
            : null}
        </div>
      ) : (
        <div className={` self-start sm:self-center flex flex-wrap  gap-y-4  gap-x-4`}>
          {detailsData?.map((item: any, index: number) => (
            <div key={index}>
              <DetailCard
                number={item?.number}
                title={item?.title}
                img={item?.img}
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default CardOne;
