import React from "react";
import MainCard from "../MainCard";
import CardOne from "./DataCards/CardOne";
import SchoolIcon from "@/public/icons/schools.svg";
import { SectorDataTypes } from "../../DashBody";
function EduDamageCard({ data, damage_percentage }: { data: SectorDataTypes, damage_percentage:string }) {
  const details = data?.details;
  return (
    <MainCard
      secondaryData={{
        relief: data?.relief,
        recovery: data?.recovery,
        development: data?.development,
      }}
      title={data?.name}
      route="/damages"
    >
      <div className="">
        <CardOne
          detailsGridCols="flex flex-col sm:grid sm:grid-cols-2 gap-x-4"
          detailsData={[
            {
              title: details?.[2]?.name,
              number: details?.[2]?.number,
              percent: details?.[2]?.damage_percentage,
              color: "#A72323",
            },
            {
              title: details?.[1]?.name,
              number: details?.[1]?.number,
              percent: details?.[1]?.damage_percentage,
              color: "#A72323",
            },
            {
              title: details?.[4]?.name,
              number: details?.[4]?.number,
              percent: details?.[4]?.damage_percentage,
              color: "#A72323",
            },
            {
              title: details?.[3]?.name,
              number: details?.[3]?.number,
              percent: details?.[3]?.damage_percentage,
              color: "#A72323",
            },
          ]}
          data={{
            icon: SchoolIcon,
            text: details?.[0]?.name,
            subtext: `${details?.[0]?.damage_percentage} ${damage_percentage}`,
            number: details?.[0]?.number,
          }}
        />
      </div>
    </MainCard>
  );
}

export default EduDamageCard;
