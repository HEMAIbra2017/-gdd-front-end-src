import React from "react";
import MainCard from "../MainCard";
import CardOne from "./DataCards/CardOne";
import { masjedIcon } from "@/app/components/icons";
import { SectorDataTypes } from "../../DashBody";

function CultureDamageCard({
  data,
  damage_percentage,
}: {
  data: SectorDataTypes;
  damage_percentage: string;
}) {
  const details = data?.details;

  return (
    <MainCard
      secondaryData={{
        relief: data?.relief,
        recovery: data?.recovery,
        development: data?.development,
      }}
      title={data?.name}
      route="/damages"
    >
      <div className="">
        <CardOne
          detailsGridCols="flex flex-col sm:grid sm:grid-cols-2 gap-x-4"
          detailsData={[
            {
              title: details?.[3]?.name,
              number: details?.[3]?.number,
              percent: details?.[3]?.damage_percentage,
            },
            {
              title: details?.[4]?.name,
              number: details?.[4]?.number,
              percent: details?.[4]?.damage_percentage,
            },
            {
              title: details?.[5]?.name,
              number: details?.[5]?.number,
              percent: details?.[5]?.damage_percentage,
            },
            {
              title: details?.[1]?.name,
              number: details?.[1]?.number,
              percent: details?.[1]?.damage_percentage,
            },
            {
              title: details?.[2]?.name,
              number: details?.[2]?.number,
              percent: details?.[2]?.damage_percentage,
            },
          ]}
          data={{
            icon: masjedIcon,
            text: details?.[0]?.name,
            subtext: `${details?.[0]?.damage_percentage} ${damage_percentage}`,
            number: details?.[0]?.number,
          }}
        />
      </div>
    </MainCard>
  );
}

export default CultureDamageCard;
