import React from "react";
import MainCard from "../MainCard";
import CardTwo from "./DataCards/CardTwo";
import {
  BombIcon,
  FanIcon,
  MedicalBottleIcon,
  StoneIcon,
  TrashIcon,
} from "../../icons/envIcons";
import { SectorDataTypes } from "../../DashBody";

function EnvDamageCard({ data }: { data: SectorDataTypes }) {
  const details = data?.details;

  return (
    <MainCard
      secondaryData={{
        relief: data?.relief,
        recovery: data?.recovery,
        development: data?.development,
      }}
      title={data?.name}
      route="/damages"
    >
      <div className="">
        <CardTwo
          viewClass="grid grid-cols-2 lg:grid-cols-3 gap-y-4  gap-x-10"
          data={[
            {
              icon: BombIcon,
              text: details?.[1]?.name,
              number: details?.[1]?.number,
            },

            {
              icon: FanIcon,
              text: details?.[3]?.name,
              number: details?.[3]?.number,
            },

            {
              icon: StoneIcon,
              text: details?.[4]?.name,
              number: details?.[4]?.number,
            },

            {
              icon: MedicalBottleIcon,
              text: details?.[6]?.name,
              number: details?.[6]?.number,
            },

            {
              icon: TrashIcon,
              text: details?.[5]?.name,
              number: details?.[5]?.number,
            },
          ]}
        />
      </div>
    </MainCard>
  );
}

export default EnvDamageCard;
