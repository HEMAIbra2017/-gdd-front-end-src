import React from "react";
import MainCard from "../MainCard";
import CardTwo from "./DataCards/CardTwo";
import {
  AmbulanceIcon,
  BuildingsIcon,
  HospitalsIcon,
} from "../../icons/healthIcons";
import { SectorDataTypes } from "../../DashBody";

function HealthDamageCard({
  data,
  damage_percentage,
}: {
  data: SectorDataTypes;
  damage_percentage: string;
}) {
  const details = data?.details;

  return (
    <MainCard
      secondaryData={{
        relief: data?.relief,
        recovery: data?.recovery,
        development: data?.development,
      }}
      title={data?.name}
      route="/damages"
    >
      <div className="">
        <CardTwo
          viewClass="flex flex-wrap items-center gap-x-12"
          data={[
            {
              icon: BuildingsIcon,
              text: details?.[2]?.name,
              subtext: `${details?.[2]?.damage_percentage} ${damage_percentage}`,
              number: details?.[2]?.number,
            },
            {
              icon: HospitalsIcon,
              text: details?.[0]?.name,
              subtext: `${details?.[0]?.damage_percentage} ${damage_percentage}`,
              number: details?.[0]?.number,
            },
            {
              icon: AmbulanceIcon,
              text: details?.[1]?.name,
              subtext: `${details?.[1]?.damage_percentage} ${damage_percentage}`,
              number: details?.[1]?.number,
            },
          ]}
        />
      </div>
    </MainCard>
  );
}

export default HealthDamageCard;
