import React from "react";
import MainProgress from "./ui/MainProgress";
import SecondaryProgress from "./ui/SecondaryProgress";
import LastUpdated from "../ui/LastUpdated";
import MainSecondaryProgress from "./ui/MobileSecondaryProgress";
import MobileSecondaryProgress from "./ui/MobileSecondaryProgress";
import { useTranslations } from "next-intl";

function DashboardHeader({
  last_updated,
  Total_Summary,
}: {
  last_updated: { time: string; date: string };
  Total_Summary: {
    relief: number;
    recovery: number;
    development: number;
    total: number;
  };
}) {
  const t = useTranslations();

  return (
    <div className="flex flex-col-reverse gap-x-12  gap-y-7   2xl:flex-row 2xl:gap-y-0">
      <div className="flex flex-col justify-end gap-y-2">
        <h1 className="text-2xl text-black3 sm:text-[32px]">{t("Sectors")}</h1>
        <LastUpdated last_updated={last_updated} />
      </div>
      <div className="flex w-full flex-col gap-x-6 gap-y-6  2xl:flex-row 2xl:gap-y-0 ">
        <MainProgress   total={Total_Summary?.total} />
        <MobileSecondaryProgress Total_Summary={Total_Summary} />
        <div className="hidden md:block">
          <SecondaryProgress Total_Summary={Total_Summary} />
        </div>
      </div>
    </div>
  );
}

export default DashboardHeader;
