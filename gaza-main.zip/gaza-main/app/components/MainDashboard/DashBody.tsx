"use client";

import React from "react";
import HumanDamageCard from "./ui/Cards/HumanDamageCard";
import HouseDamageCard from "./ui/Cards/HouseDamageCard";
import CultureDamageCard from "./ui/Cards/CultureDamageCard";
import HealthDamageCard from "./ui/Cards/HealthDamageCard";
import EconomicDamageCard from "./ui/Cards/EconomicDamageCard";
import EduDamageCard from "./ui/Cards/EduDamageCard";
import ServicesDamageCard from "./ui/Cards/ServicesDamageCard";
import EnvDamageCard from "./ui/Cards/EnvDamageCard";
import { useTranslations } from "next-intl";
import GovernaceDamageCard from "./ui/Cards/GovernaceDamageCard";

export type SectorDataTypes = {
  name: string;
  relief: number;
  recovery: number;
  development: number;
  details: {
    id: number;
    name: string;
    number: string;
    damage_percentage: string;
  }[];
};
function DashBody({ data }: { data: SectorDataTypes[] }) {
  const t = useTranslations();

  return (
    <div className="my-[18px] gap-x-4 space-y-4 sm:my-8   xl:columns-2 ">
      <HumanDamageCard
        percentage_text={t("Percentage of Total Gaza Strip Population")}
        data={data?.[0]}
      />
      <HealthDamageCard
        damage_percentage={t("Percentage of damage")}
        data={data?.[1]}
      />
      <EnvDamageCard data={data?.[6]} />
      <ServicesDamageCard
        damage_percentage={t("Percentage of damage")}
        data={data?.[5]}
      />
      <EduDamageCard
        damage_percentage={t("Percentage of damage")}
        data={data?.[3]}
      />
      <EconomicDamageCard
        damage_percentage={t("Percentage of damage")}
        data={data?.[7]}
      />
      <CultureDamageCard
        damage_percentage={t("Percentage of damage")}
        data={data?.[2]}
      />

      <HouseDamageCard
        damage_percentage={t("Percentage of damage")}
        data={data?.[4]}
      />
      <GovernaceDamageCard
        damage_percentage={t("Percentage of damage")}
        data={data?.[8]}
      />
    </div>
  );
}

export default DashBody;
