import React from "react";
import DashboardHeader from "./DashboardHeader";
import DashBody from "./DashBody";
import Hero from "./ui/Hero";
import { fetchData } from "@/helpers/fetchData";
import { useLocale, useTranslations } from "next-intl";

async function MainDashboard() {
  const locale = useLocale();
  const data = await fetchData({
    url: "/main",
    locale,
  });

  return (
    <>
      <Hero data={data?.hero} />
      <div className="container">
        <DashboardHeader
          last_updated={data?.last_updated}
          Total_Summary={data?.Total_Summary[0]}
        />
        <DashBody data={data?.Sectors} />
      </div>
    </>
  );
}

export default MainDashboard;
