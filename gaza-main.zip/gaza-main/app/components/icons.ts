import shohadaaIcon from "@/public/icons/data/shohadaa.svg";
import mosabeenIcon from "@/public/icons/data/mosabeen.svg";
import babyIcon from "@/public/icons/data/baby-icon.svg";
import femaleIcon from "@/public/icons/data/female-icon.svg";
import maleIcon from "@/public/icons/data/male-icon.svg";
import RedhomeIcon from "@/public/icons/data/home-icon-2.svg";
import questionMarkIcon from "@/public/icons/data/question-mark.svg";
import homeless from "@/public/icons/data/homeless.svg";
import masjedIcon from "@/public/icons/data/masjed.svg";
import schoolIcon from "@/public/icons/data/school.svg";
import Logo from "@/public/logo.svg";
import BurgerIcon from "@/public/icons/burger.svg";
import CloseIcon from "@/public/icons/close.svg";
import ChevronIcon from "@/public/icons/chevronIcon.svg";
import CopyIcon from "@/public/icons/copy.svg";
import ShareIcon from "@/public/icons/share.svg";

export {
  shohadaaIcon,
  babyIcon,
  mosabeenIcon,
  femaleIcon,
  maleIcon,
  RedhomeIcon,
  questionMarkIcon,
  homeless,
  masjedIcon,
  schoolIcon,
  Logo,
  BurgerIcon,
  CloseIcon,
  ChevronIcon,
  CopyIcon,
  ShareIcon,
};
