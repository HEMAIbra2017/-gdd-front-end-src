"use client";

import dynamic from "next/dynamic";
import React from "react";
const Chart = dynamic(() => import("react-apexcharts"), { ssr: false });

function Donut({ labels, series, type }: any) {
  const options = {
    chart: {
      fontFamily: "Cairo, Arial, sans-serif",
    },
    labels,
    dataLabels: {
      enabled: true,
      style: {
        fontSize: "12px",
        fontFamily: "Helvetica, Arial, sans-serif",
        fontWeight: "bold",
      },
    },
  };

  return (
    <div>
      <Chart
        height={200}
        options={options}
        series={series}
        type="pie"
        width="380"
      />
    </div>
  );
}

export default Donut;
