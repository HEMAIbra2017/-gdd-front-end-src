import { cookies } from "next/headers";

export async function POST(request: Request) {
  const cookieStore = cookies();
  const token = cookieStore.get("token")?.value;
  
  const formData = await request.formData();
  const myHeaders = new Headers();
  myHeaders.append("Authorization", `Token ${token}`);

  const res = await fetch(
    "https://gdd-api.secdy.com/api/update-data/excel-upload/",
    {
      method: "POST",
      headers: myHeaders,
      body: formData,
    },
  );
  
  const data = await res.json();
  return Response.json(data, {
    status: res?.status,
  });
}
