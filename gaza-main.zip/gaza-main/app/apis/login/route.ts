export async function POST(request: Request) {
  const requestData = await request.json();
  const res = await fetch(
    "https://gdd-api.secdy.com/api/accounts/login/",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept-Language": (requestData?.locale || "en").toLowerCase(),
      },
      body: JSON.stringify(requestData?.data),
    },
  );

  const data = await res.json();
  return Response.json(data, {
    status: res?.status,
  });
}
