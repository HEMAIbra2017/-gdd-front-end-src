import { cookies } from "next/headers";

export async function POST() {
  const cookieStore = cookies();
  const token = cookieStore.get("token")?.value;

  const res = await fetch(
    "https://gdd-api.secdy.com/api/accounts/logout/",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Token ${token}`,
      },
    },
  );

  const data = await res.json();
  return Response.json(data, {
    status: res?.status,
  });
}
